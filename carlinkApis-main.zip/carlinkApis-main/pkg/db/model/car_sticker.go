package model

type CarSticker struct {
	CarStickerId uint64 `gorm:"primary_key;column:car_sticker_id;type:bigint;not null" json:"car_sticker_id"`
	CarId        uint64 `gorm:"column:car_id;type:bigint;not null" json:"car_id"`
	StickerId    uint64 `gorm:"column:sticker_id;type:bigint;not null" json:"sticker_id"`
	IsActive     bool   `gorm:"column:is_active;type:bool;not null" json:"is_active"`
	Deleted      bool   `gorm:"column:deleted;type:bool;not null" json:"deleted"`
}
