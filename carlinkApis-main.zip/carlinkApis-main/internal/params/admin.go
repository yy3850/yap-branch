package params

type AdminLoginPayload struct {
	UserName string `json:"user_name" binding:"required"`
	Password string `json:"password" binding:"required"`
}

type AdminLoginResponse struct {
	IsSuccess bool         `json:"is_success"`
	ErrorMsg  string       `json:"err_msg,omitempty"`
	Admin     *AdminDetail `json:"admin,omitempty"`
}

type AdminDetail struct {
	AdminId   uint64 `json:"admin_id"`
	RoleId    uint64 `json:"role_id"`
	CompanyId uint64 `json:"company_id"`
	UserName  string `json:"user_name"`
	Name      string `json:"name"`
	Token     string `json:"token"`
}

type CreateAdminPayload struct {
	UserName string `json:"user_name" binding:"required"`
	Name     string `json:"name" binding:"required"`
	Password string `json:"password" binding:"required"`
	RoleId   uint64 `json:"role_id" binding:"required"`
	Email    string `json:"email" binding:"required"`
}
