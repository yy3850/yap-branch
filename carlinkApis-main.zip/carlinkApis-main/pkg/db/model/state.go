package model

type State struct {
	StateId   uint64 `gorm:"primary_key;column:state_id;type:bigint;not null" json:"state_id"`
	StateName string `gorm:"column:state;type:varchar(255);not null" json:"state_name"`
	ShortForm string `gorm:"column:short_form;type:varchar(255);not null" json:"short_form"`
}
