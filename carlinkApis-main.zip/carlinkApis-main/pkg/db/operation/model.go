package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	ModelTab           = "model"
	ModelStatusDeleted = 1
)

func GetModelList(modelId uint64, brandId uint64) (models []*model.Model, err error) {
	db := db.CarLinkDB.Table(ModelTab)
	if modelId != 0 {
		db = db.Where("model_id = ?", modelId)
	}

	if brandId != 0 {
		db = db.Where("brand_id = ?", brandId)
	}
	db = db.Where("deleted != ?", ModelStatusDeleted)
	res := db.Find(&models)
	return models, res.Error
}
