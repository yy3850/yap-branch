package auction

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/auction_section"
	"carlink/pkg/processor/car"

	"github.com/gin-gonic/gin"
)

func GetAuctions(c *gin.Context) {
	var req params.GetAuctionParam
	var res params.AuctionResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	// err := admin.IsValidToken(c)
	// if err != nil {
	// 	processor.ErrorResponse(c, req, 403, err.Error())
	// 	return
	// }

	auctionList, err := operation.GetAuctionList(req.AuctionId, req.CarId, req.AuctionSectionId, req.AuctionStatusId)
	if err != nil {
		processor.ErrorResponse(c, nil, 400, err.Error())
		return
	}

	auctionsResp := ConvertAuctionSectionResponse(auctionList)

	// add car & auction section details
	for _, acauctionResp := range auctionsResp {
		carDetails, err := operation.GetCarWithObjectById(acauctionResp.Car.CarId)
		if err != nil {
			processor.ErrorResponse(c, nil, 400, err.Error())
			return
		}
		if carDetails != nil {
			acauctionResp.Car = car.ConvertCarResponseWithDisplayUrl([]*model.CarWithObject{carDetails})[0]
		}

		auctionSectionDetails, err := operation.GetAuctionSectionById(acauctionResp.AuctionSection.AuctionSectionId)
		if err != nil {
			processor.ErrorResponse(c, nil, 400, err.Error())
			return
		}

		acauctionResp.AuctionSection = auction_section.ConvertSingleAuctionSectionResponse(auctionSectionDetails)
	}

	res.AuctionDetail = auctionsResp

	res.IsSuccess = true
	c.JSON(200, res)
}
