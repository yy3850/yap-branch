package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
	"sync"

	"gorm.io/gorm/clause"
)

const (
	CarInspectionTab          = "car_inspection"
	CarInspentionStatusActive = 0
)

func GetCarInspectionList(carId uint64, inspectionDetailId uint64) (carInspections []*model.CarInspection, err error) {
	db := db.CarLinkDB.Table(CarInspectionTab)
	if carId != 0 {
		db = db.Where("car_id = ?", carId)
	}

	if inspectionDetailId != 0 {
		db = db.Where("inspection_detail_id = ?", inspectionDetailId)
	}

	db = db.Where("deleted = ?", CarInspentionStatusActive)
	res := db.Find(&carInspections)

	return carInspections, res.Error
}

func UpsertCarInspections(carInspections []*model.CarInspection, wg *sync.WaitGroup) (results []*model.CarInspection, err error) {
	defer wg.Done()
	db := db.CarLinkDB.Table(CarInspectionTab)
	db.Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "car_id"}, {Name: "inspection_type_id"}}, // key colume
		DoUpdates: clause.AssignmentColumns([]string{"remarks", "images"}),         // column to be updated
	}).Create(&carInspections)

	return results, nil
}
