package model

//import "time"

type Auction struct {
	AuctionId        uint64  `gorm:"primary_key;column:auction_id;type:bigint;not null" json:"auction_id"`
	AuctionSectionId uint64  `gorm:"column:auction_section_id;type:bigint;not null" json:"auction_section_id"`
	CarId            uint64  `gorm:"column:car_id;type:bigint;not null" json:"car_id"`
	StartingPrice    float64 `gorm:"column:starting_price;type:float;not null" json:"starting_price"`
	ExpectedPrice    float64 `gorm:"column:expected_price;type:float;not null" json:"expected_price"`
	DepositAmount    float64 `gorm:"column:deposit_amount;type:float;not null" json:"deposit_amount"`
	AuctionStatusId  uint64  `gorm:"column:auction_status_id;type:bigint;not null" json:"auction_status_id"`
	Date             string  `gorm:"column:date;type:date;not null" json:"date"`
	StartTime        string  `gorm:"column:start_time;type:time;not null" json:"start_time"`
	EndTime          string  `gorm:"column:end_time;type:time;not null" json:"end_time"`
	StartTimestamp   int64   `gorm:"column:start_timestamp;type:bigint;not null" json:"start_timestamp"`
	EndTimestamp     int64   `gorm:"column:end_timestamp;type:bigint;not null" json:"end_timestamp"`
	AuctionRemark    string  `gorm:"column:auction_remark;type:varchar(255);not null" json:"auction_remark"`
	CreatedBy        uint64  `gorm:"column:created_by;type:bigint;not null" json:"created_by"`
	CreatorName      string
	TotalBid         int64
	FinalBid         float32
	TotalBuyer       int64
	BuyerId          uint64
	BuyerName        string
}

type CarAuctionStatus struct {
	CarId           uint64 `gorm:"column:car_id;type:bigint;not null" json:"car_id"`
	AuctionStatusId uint64 `gorm:"column:auction_status_id;type:bigint;not null" json:"auction_status_id"`
}
