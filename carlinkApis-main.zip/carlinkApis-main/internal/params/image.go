package params

type UploadImageResponse struct {
	IsSuccess bool   `json:"is_success"`
	Key       string `json:"url,omitempty"`
	ErrorMsg  string `json:"err_msg,omitempty"`
}
