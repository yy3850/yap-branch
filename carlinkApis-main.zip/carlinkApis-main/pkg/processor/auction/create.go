package auction

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"carlink/pkg/logger"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"fmt"

	"github.com/gin-gonic/gin"
)

func CreateAuction(c *gin.Context) {
	var req params.CreateAuctionPayload
	var res params.AuctionResponse
	res.IsSuccess = false
	if err := c.ShouldBindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	creator, err := admin.GetAdminDetail(c)
	if err != nil || creator.AdminId == 0 {
		processor.ErrorResponse(c, req, 404, "authentication failed")
		return
	}

	if creator.RoleId != 1 {
		processor.ErrorResponse(c, req, 404, "only admin can add car to auction")
		return
	}

	currentCars, err := operation.GetCarListByIds(req.CarIds)
	if err != nil || len(currentCars) != len(req.CarIds) {
		processor.ErrorResponse(c, req, 400, "retrieve car details failed")
		return
	}

	for _, currentCar := range currentCars {
		if currentCar.Status == operation.CarStatusPending {
			processor.ErrorResponse(c, req, 400, fmt.Sprintf("car with plant no '%+v' still in Pending status.", currentCar.LicensePlateNo))
			return
		}
	}

	currentAuctionSection, err := operation.GetAuctionSectionById(req.AuctionSectionId)
	if err != nil || currentAuctionSection.AuctionSectionId == 0 {
		processor.ErrorResponse(c, req, 400, "retrieve auction section details failed")
		return
	}

	var auctions []*model.Auction
	for _, currentCar := range currentCars {
		auctions = append(auctions, &model.Auction{
			CarId:            currentCar.CarId,
			AuctionSectionId: req.AuctionSectionId,
			StartingPrice:    currentCar.Price,
			ExpectedPrice:    currentCar.Price,
			DepositAmount:    GetDepositPrice(currentCar.Price),
			Date:             currentAuctionSection.Date,
			StartTime:        currentAuctionSection.StartTime,
			EndTime:          currentAuctionSection.EndTime,
			AuctionRemark:    GetAuctionRemark(GetDepositPrice(currentCar.Price)),
			CreatedBy:        creator.AdminId,
			AuctionStatusId:  1,
			StartTimestamp:   currentAuctionSection.StartTimestamp,
			EndTimestamp:     currentAuctionSection.EndTimestamp,
		})
	}
	auctionsResp, err := operation.InsertAuction(auctions)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	res.AuctionDetail = ConvertAuctionSectionResponse(auctionsResp)
	res.IsSuccess = true

	logger.InfoLogger.Println(fmt.Sprintf("New auction created. %+v", req))
	c.JSON(200, res)
}
