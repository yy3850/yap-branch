package transmission

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"github.com/gin-gonic/gin"
)

func GetTransmission(c *gin.Context) {
	var req params.GetTransmissionParam
	var res params.GetTransmissionResponse
	res.IsSuccess = false
	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	err := admin.IsValidToken(c)
	if err != nil {
		processor.ErrorResponse(c, nil, 403, err.Error())
		return
	}

	transmissions, err := operation.GetTransmissionList(req.TransmissionId)
	if err != nil {
		processor.ErrorResponse(c, nil, 400, err.Error())
		return
	}

	var transmissionResp []*params.TransmissionDetail
	for _, t := range transmissions {
		transmissionResp = append(transmissionResp, &params.TransmissionDetail{
			TransmissionId: t.TransmissionId,
			Name:           t.Name,
		})
	}

	res.Transmissions = transmissionResp
	res.IsSuccess = true
	c.JSON(200, res)
}
