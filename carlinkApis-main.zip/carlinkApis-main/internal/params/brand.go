package params

type GetBrandRequest struct {
	BrandId uint64 `form:"brand_id"json:"brand_id"`
}

type GetBrandResponse struct {
	IsSuccess bool           `json:"is_success"`
	ErrorMsg  string         `json:"err_msg,omitempty"`
	Brands    []*BrandDetail `json:"brands,omitempty"`
}

type BrandDetail struct {
	BrandId   uint64 `json:"brand_id"`
	BrandName string `json:"brand_name"`
	Logo      []byte `json:"logo"`
}
