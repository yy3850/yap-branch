package model

type Transmission struct {
	TransmissionId uint64 `gorm:"primary_key;column:transmission_id;type:bigint;not null" json:"transmission_id"`
	Name           string `gorm:"column:name;type:varchar(255);not null" json:"name"`
}
