package car

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"fmt"
)

func ConvertCarResponse(car *model.CarWithObject) *params.CarDetail {
	return &params.CarDetail{
		CarId:            car.CarId,
		UserId:           car.UserId,
		LicensePlateNo:   car.LicensePlateNo,
		Mileage:          car.Mileage,
		ManufactureYear:  car.ManufactureYear,
		RegistrationDate: car.RegistrationDate,
		Brand: &params.BrandDetail{
			BrandId:   car.BrandId,
			BrandName: car.BrandName,
		},
		Model: &params.ModelDetail{
			ModelId:   car.ModelId,
			ModelName: car.ModelName,
		},
		Variant: &params.VariantDetail{
			VariantId:   car.VariantId,
			VariantName: car.VariantName,
		},
		Transmission: &params.TransmissionDetail{
			TransmissionId: car.TransmissionId,
			Name:           car.TransmissionName,
		},
		EngineNo:       car.EngineNo,
		EngineCapacity: car.EngineCapacity,
		ChassisNo:      car.ChassisNo,
		Color: &params.ColorDetail{
			ColorId:   car.ColorId,
			ColorName: car.ColorName,
		},
		FuelType:     car.FuelType,
		ExistingLoan: car.ExistingLoan,
		NoOfSeat:     car.NoOfSeat,
		State: &params.StateDetail{
			StateId:   car.StateId,
			StateName: car.StateName,
		},
		RegistrationType: car.RegistrationType,
		SellWithPlateNo:  car.SellWithPlateNo,
		AuctionRemark:    car.AuctionRemark,
		Price:            car.Price,
		CreateBy:         car.CreatedBy,
		CreateTime:       car.CreateTime,
		DisplayUrl:       car.DisplayUrl,
		Status:           car.Status,
	}
}

func ConvertCarResponseWithDisplayUrl(carList []*model.CarWithObject) []*params.CarDetail {
	var carResps []*params.CarDetail
	// add display url
	for _, car := range carList {
		car.DisplayUrl = operation.GetDisplayImageByCarId(car.CarId)
		carResps = append(carResps, ConvertCarResponse(car))
	}

	// add sticker
	for _, carResp := range carResps {
		var stickers []*params.CarStickerDetails
		stickerParams, _ := operation.GetCarStickerList(&model.CarSticker{CarId: carResp.CarId})
		for _, sParam := range stickerParams {
			stickers = append(stickers, &params.CarStickerDetails{
				CarStickerId: sParam.CarStickerId,
				StickerId:    sParam.StickerId,
				IsActive:     sParam.IsActive,
			})
		}

		carResp.Stickers = stickers
	}

	return carResps
}

func CheckCanUpdateToAvailable(carId uint64) (err error) {
	var mandatoryIdList []uint64
	for key, _ := range processor.CarImageIDMandatoryList {
		mandatoryIdList = append(mandatoryIdList, key)
	}
	typeIdMap, err := operation.GetCarImageMap(carId, mandatoryIdList)
	if err != nil {
		return
	}

	for k, v := range processor.CarImageIDMandatoryList {
		if !typeIdMap[k] {
			err = fmt.Errorf("car image missing. required id: %+v, type: %+v", k, v)
		}
	}

	return
}
