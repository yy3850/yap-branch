package car_image_type

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"

	"github.com/gin-gonic/gin"
)

func GetCarImageType(c *gin.Context) {
	var req params.GetCarImageTypeParam
	var res params.GetCarImageTypeResponse
	res.IsSuccess = false
	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	// err := admin.IsValidToken(c)
	// if err != nil {
	// 	processor.ErrorResponse(c, req, 403, err.Error())
	// 	return
	// }

	ImgTypeList, err := operation.GetCarImageTypeList(req.CarImageTypeId, req.TypeName)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	var carImageTypeResp []*params.CarImageTypeDetail
	for _, carImageType := range ImgTypeList {
		carImageTypeResp = append(carImageTypeResp, &params.CarImageTypeDetail{
			TypeId:      carImageType.TypeId,
			TypeName:    carImageType.TypeName,
			SubTypeName: carImageType.SubTypeName,
			IsMandatory: carImageType.IsMandatory,
			IsMultiple:  carImageType.IsMultiple,
		})
	}

	res.CarImageTypes = carImageTypeResp
	res.IsSuccess = true
	c.JSON(200, res)
}
