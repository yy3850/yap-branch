package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	AuctionSectionTab           = "auction_section"
	AuctionSectionStatusDeleted = 1
)

func GetAuctionSectionById(id uint64) (auctionSection *model.AuctionSection, err error) {
	db := db.CarLinkDB.Table(AuctionSectionTab)
	if id != 0 {
		db = db.Where("auction_section_id = ?", id)
	}
	db = db.Where("deleted != ?", AuctionSectionStatusDeleted)
	res := db.Find(&auctionSection)
	return auctionSection, res.Error
}

func GetAuctionSectionList(auctionSectionId uint64, startTime int64, endTime int64) (auctionSections []*model.AuctionSection, err error) {
	db := db.CarLinkDB.Table(AuctionSectionTab)
	db.Model(&auctionSections).Select("auction_section.*, count(a.auction_id) as total_auction").
		Joins("left join carlink.auction  as a Using(auction_section_id)")

	if auctionSectionId != 0 {
		db = db.Where("auction_section.auction_section_id = ?", auctionSectionId)
	}

	if startTime != 0 {
		db = db.Where("auction_section.start_timestamp >= ?", startTime)
	}

	if endTime != 0 {
		db = db.Where("auction_section.end_timestamp <= ?", endTime)
	}

	db.Group("auction_section.auction_section_id")

	db = db.Where("auction_section.deleted != ?", AuctionSectionStatusDeleted)
	res := db.Find(&auctionSections)
	return auctionSections, res.Error
}

func InsertAuctionSection(auctionSection *model.AuctionSection) (*model.AuctionSection, error) {
	db := db.CarLinkDB.Table(AuctionSectionTab)
	res := db.Omit("total_auction").Create(auctionSection)

	if res.Error != nil {
		return nil, res.Error
	}
	return auctionSection, nil
}
