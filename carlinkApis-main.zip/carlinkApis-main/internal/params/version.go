package params

type GetVersionPayload struct {
	IsLatest bool `form:"is_latest" url:"is_latest"`
}

type GetVersionListResponse struct {
	IsSuccess bool             `json:"is_success"`
	Versions  []*VersionDetail `json:"versions,omitempty"`
}

type VersionDetail struct {
	VersionId   uint64 `json:"version_id"`
	VersionName string `json:"version_name"`
	Desc        string `json:"desc"`
}
