package web

import (
	"carlink/pkg/processor/admin"
	"carlink/pkg/processor/auction"
	"carlink/pkg/processor/auction_section"
	"carlink/pkg/processor/bid"
	"carlink/pkg/processor/brand"
	"carlink/pkg/processor/car"
	"carlink/pkg/processor/car_image"
	"carlink/pkg/processor/car_image_type"
	"carlink/pkg/processor/car_inspection"
	"carlink/pkg/processor/car_sticker"
	"carlink/pkg/processor/color"
	"carlink/pkg/processor/image"
	"carlink/pkg/processor/inspection_detail"
	"carlink/pkg/processor/model"
	"carlink/pkg/processor/state"
	"carlink/pkg/processor/sticker"
	"carlink/pkg/processor/transmission"
	"carlink/pkg/processor/user"
	"carlink/pkg/processor/variant"
	"carlink/pkg/processor/version"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

func Run() {
	gin.SetMode(gin.ReleaseMode)

	router := gin.New()
	router.Use(gin.Logger())
	router.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"*"},
		AllowMethods:     []string{"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"},
		AllowHeaders:     []string{"*"},
		ExposeHeaders:    []string{"*"},
		AllowCredentials: true,
		// AllowOriginFunc: func(origin string) bool {
		// 	return origin == "https://github.com"
		// },
		MaxAge: 12 * time.Hour,
	}))

	carlinkAPI := router.Group("/carlink_backend/v2")

	// admin api
	adminAPI := carlinkAPI.Group("/admin")
	adminAPI.POST("/login", admin.Login)

	// state api
	stateAPI := carlinkAPI.Group("/state")
	stateAPI.GET("/get", state.GetStates)

	// brand api
	brandAPI := carlinkAPI.Group("/brand")
	brandAPI.GET("/get", brand.GetBrands)

	// model api
	modelAPI := carlinkAPI.Group("/model")
	modelAPI.GET("/get", model.GetModel)

	// color api
	colorAPI := carlinkAPI.Group("/color")
	colorAPI.GET("/get", color.GetColor)

	// variant api
	variantAPI := carlinkAPI.Group("/variant")
	variantAPI.GET("/get", variant.GetVariant)

	// image api
	imageAPI := carlinkAPI.Group("/image")
	imageAPI.POST("/upload", image.UploadImage)

	// sticker api
	stickerAPI := carlinkAPI.Group("/sticker")
	stickerAPI.GET("/get", sticker.GetSticker)

	// transmission api
	transmissionAPI := carlinkAPI.Group("/transmission")
	transmissionAPI.GET("/get", transmission.GetTransmission)

	// user api
	userAPI := carlinkAPI.Group("/user")
	userAPI.GET("/get", user.GetUsers)
	userAPI.POST("/post", user.Register)

	// car image type api
	carImageTypeAPI := carlinkAPI.Group("/car_image_type")
	carImageTypeAPI.GET("/get", car_image_type.GetCarImageType)

	// car api
	carAPI := carlinkAPI.Group("/car")
	carAPI.GET("/get", car.GetCarList)
	carAPI.POST("/create", car.CreateCar)
	carAPI.POST("/update", car.UpdateCar)
	carAPI.POST("/delete", car.DeleteCar)
	carAPI.POST("/update_status", car.UpdateStatus)

	// car image api
	carImageAPI := carlinkAPI.Group("/car_image")
	carImageAPI.GET("/get", car_image.GetCarImage)
	carImageAPI.POST("/upsert", car_image.UpsertCarImage)
	carImageAPI.POST("/delete", car_image.DeleteCarImage)

	// car sticket api
	carStickerAPI := carlinkAPI.Group("/car_sticker")
	carStickerAPI.GET("/get", car_sticker.GetCarSticker)
	carStickerAPI.POST("/upsert", car_sticker.UpsertCarSticker)

	// inspection detail api
	inspectionDetailAPI := carlinkAPI.Group("/inspection")
	inspectionDetailAPI.GET("/get", inspection_detail.GetInspectionDetailList)

	// car inspection detail api
	carInspectionDetailAPI := carlinkAPI.Group("/car_inspection")
	carInspectionDetailAPI.GET("/get", car_inspection.GetCarInspections)
	carInspectionDetailAPI.POST("/upsert", car_inspection.UpsertCarInspection)

	// auction section api
	auctionSectionAPI := carlinkAPI.Group("/auction_section")
	auctionSectionAPI.GET("/get", auction_section.GetAuctionSections)
	auctionSectionAPI.POST("/create", auction_section.CreateAuctionSection)

	// auction api
	auctionAPI := carlinkAPI.Group("/auction")
	auctionAPI.GET("/get", auction.GetAuctions)
	auctionAPI.POST("/create", auction.CreateAuction)

	// bid api
	bidAPI := carlinkAPI.Group("/bid")
	bidAPI.GET("/get", bid.GetBids)

	// version api
	versionAPI := carlinkAPI.Group("/version")
	versionAPI.GET("/get", version.GetVersions)

	// sms api
	smsPI := carlinkAPI.Group("/sms")
	smsPI.POST("/send", user.SendSMS)

	router.Run(":80")
}
