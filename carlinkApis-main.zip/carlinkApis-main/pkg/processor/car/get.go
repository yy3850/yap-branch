package car

import (
	"carlink/internal/params"
	"carlink/pkg/db"
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"

	"github.com/gin-gonic/gin"
)

func GetCarList(c *gin.Context) {
	var req params.GetCarRequest
	var res params.GetCarResponse
	res.IsSuccess = false
	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	operator, err := admin.GetAdminDetail(c)
	if err != nil || operator.AdminId == 0 {
		processor.ErrorResponse(c, req, 403, "authentication failed")
		return
	}

	// not admin role can only retrieve own created car
	if operator.RoleId != 1 {
		req.CreatedBy = operator.AdminId
	}

	//status := req.Status
	//if req.Status != "" && req.Status != "Pending" && req.Status != "Available" {
	//	processor.ErrorResponse(c, req, 400, "invalid status")
	//	return
	//}

	carList, err := operation.GetCarWithObject(&model.Car{
		CarId:     req.CarId,
		CreatedBy: req.CreatedBy,
		BrandId:   req.BrandId,
		ModelId:   req.ModelId,
		Status:    req.Status,
	},
		&db.CommonCondition{
			Limit:  req.Limit,
			Offset: req.Offset,
		},
		req.KeyWords,
	)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	if req.Offset != nil || req.Limit != nil {
		res.Pagination = &params.Pagination{
			Offset: req.Offset,
			Limit:  req.Limit,
		}
	}

	res.CarDetails = ConvertCarResponseWithDisplayUrl(carList)
	res.IsSuccess = true
	c.JSON(200, res)
}
