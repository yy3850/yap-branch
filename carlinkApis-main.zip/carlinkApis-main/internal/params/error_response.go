package params

type ErrorResponse struct {
	IsSuccess bool   `json:"is_success"`
	ErrorMsg  string `json:"err_msg,omitempty"`
}
