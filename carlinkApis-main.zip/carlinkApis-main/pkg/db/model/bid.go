package model

type Bid struct {
	BidId    uint64  `gorm:"primary_key;column:bid_id;type:bigint;not null" json:"bid_id"`
	Price    float32 `gorm:"column:price;type:float;not null" json:"price"`
	UserId   uint64  `gorm:"column:user_id;type:bigint;not null" json:"user_id"`
	UserName string  `gorm:"column:name;type:varchar(255);not null" json:"user_name"`
}
