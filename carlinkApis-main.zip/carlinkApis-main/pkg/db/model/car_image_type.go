package model

type CarImageType struct {
	TypeId      uint64 `gorm:"primary_key;column:type_id;type:bigint;not null" json:"type_id"`
	TypeName    string `gorm:"column:type_name;type:varchar(255);not null" json:"type_name"`
	SubTypeName string `gorm:"column:sub_type_name;type:varchar(255);not null" json:"sub_type_name"`
	IsMandatory bool   `gorm:"column:is_mandatory;type:boolean;not null" json:"is_mandatory"`
	IsMultiple  bool   `gorm:"column:is_multiple;type:boolean;not null" json:"is_multiple"`
}
