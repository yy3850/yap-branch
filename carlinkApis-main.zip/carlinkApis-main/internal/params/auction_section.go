package params

type GetAuctionSectionParam struct {
	AuctionSectionId uint64 `form:"auction_section_id"json:"auction_section_id"`
	StartTime        int64  `form:"start_time"json:"start_time"`
	EndTime          int64  `form:"end_time"json:"end_time"`
}

type CreateAuctionSectionPayload struct {
	StartTime int64 `json:"start_time" binding:"required"`
	EndTime   int64 `json:"end_time" binding:"required"`
}

type DeleteAuctionSectionPayload struct {
	AuctionSectionId uint64 `json:"auction_section_id" binding:"required"`
}

type AuctionSectionResponse struct {
	IsSuccess             bool                    `json:"is_success"`
	AuctionSectionDetails []*AuctionSectionDetail `json:"auction_section_details,omitempty"`
}

type AuctionSectionDetail struct {
	AuctionSectionId uint64 `json:"auction_section_id"`
	TotalVehicles    int64  `json:"total_vehicles"`
	Status           string `json:"status"`
	StartTime        int64  `json:"start_time"`
	EndTime          int64  `json:"end_time"`
}
