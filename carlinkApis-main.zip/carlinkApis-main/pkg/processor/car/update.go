package car

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"carlink/pkg/logger"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"errors"
	"fmt"
	"regexp"

	"github.com/gin-gonic/gin"
)

func UpdateCar(c *gin.Context) {
	var req params.UpdateCarPayload
	var res params.CarResponse
	res.IsSuccess = false
	if err := c.ShouldBindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	creator, err := admin.GetAdminDetail(c)
	if err != nil || creator.AdminId == 0 {
		processor.ErrorResponse(c, req, 403, "authentication failed")
		return
	}

	if err = validateUpdateRequest(req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	currentCar, err := operation.GetCarById(req.CarId)
	if err != nil || currentCar.CarId == 0 {
		processor.ErrorResponse(c, req, 400, "retrieve car details failed")
		return
	}

	if currentCar.CreatedBy != creator.AdminId && creator.RoleId != 1 {
		processor.ErrorResponse(c, req, 403, "only creator or admin can update")
		return
	}

	updateCurrentCar(req, currentCar)
	newCar, err := operation.UpdateCar(currentCar)

	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	carDetails, _ := operation.GetCarWithObjectById(newCar.CarId)
	res.CarDetail = ConvertCarResponse(carDetails)
	res.IsSuccess = true

	logger.InfoLogger.Println(fmt.Sprintf("Car updated. %+v", req))
	c.JSON(200, res)
}

func updateCurrentCar(req params.UpdateCarPayload, currentCar *model.Car) {
	if req.UserId != 0 {
		currentCar.UserId = req.UserId
	}
	if req.LicensePlateNo != "" {
		currentCar.LicensePlateNo = req.LicensePlateNo
	}
	if req.Mileage != 0 {
		currentCar.Mileage = req.Mileage
	}
	if req.ManufactureYear != 0 {
		currentCar.ManufactureYear = req.ManufactureYear
	}
	if req.RegistrationDate != 0 {
		currentCar.RegistrationDate = req.RegistrationDate
	}
	if req.BrandId != 0 {
		currentCar.BrandId = req.BrandId
	}
	if req.ModelId != 0 {
		currentCar.ModelId = req.ModelId
	}
	if req.VariantId != 0 {
		currentCar.VariantId = req.VariantId
	}
	if req.TransmissionId != 0 {
		currentCar.TransmissionId = req.TransmissionId
	}
	if req.EngineNo != "" {
		currentCar.EngineNo = req.EngineNo
	}
	if req.EngineCapacity != "" {
		currentCar.EngineCapacity = req.EngineCapacity
	}
	if req.ChassisNo != "" {
		currentCar.ChassisNo = req.ChassisNo
	}
	if req.ColorId != 0 {
		currentCar.ColorId = req.ColorId
	}
	if req.FuelType != "" {
		currentCar.FuelType = req.FuelType
	}
	if req.NoOfSeat != 0 {
		currentCar.NoOfSeat = req.NoOfSeat
	}
	if req.StateId != 0 {
		currentCar.StateId = req.StateId
	}
	if req.RegistrationType != "" {
		currentCar.RegistrationType = req.RegistrationType
	}
	if req.AuctionRemark != "" {
		currentCar.AuctionRemark = req.AuctionRemark
	}
	if req.Price != 0 {
		currentCar.Price = req.Price
	}
	if req.ExistingLoan != nil {
		currentCar.ExistingLoan = *req.ExistingLoan
	}
	if req.SellWithPlateNo != nil {
		currentCar.SellWithPlateNo = *req.SellWithPlateNo
	}
}

func validateUpdateRequest(req params.UpdateCarPayload) (err error) {
	if lst, _ := operation.GetUserList(req.UserId); len(lst) == 0 && req.UserId != 0 {
		return errors.New("invalid user id")
	}

	if lst, _ := operation.GetModelList(req.ModelId, 0); len(lst) == 0 && req.ModelId != 0 {
		return errors.New("invalid model id")
	}

	if lst, _ := operation.GetBrandList(req.BrandId); len(lst) == 0 && req.BrandId != 0 {
		return errors.New("invalid brand id")
	}

	if lst, _ := operation.GetVariantList(req.VariantId, 0); len(lst) == 0 && req.VariantId != 0 {
		return errors.New("invalid variant id")
	}

	if lst, _ := operation.GetTransmissionList(req.TransmissionId); len(lst) == 0 && req.TransmissionId != 0 {
		return errors.New("invalid transmission id")
	}

	if lst, _ := operation.GetColorList(req.ColorId); len(lst) == 0 && req.ColorId != 0 {
		return errors.New("invalid color id")
	}

	if lst, _ := operation.GetStateList(req.StateId); len(lst) == 0 && req.StateId != 0 {
		return errors.New("invalid state id")
	}

	aiReg, _ := regexp.Compile("^[a-zA-Z0-9]*$")
	if req.LicensePlateNo != "" && !aiReg.MatchString(req.LicensePlateNo) {
		return errors.New("invalid plate no")
	}
	if req.EngineNo != "" && !aiReg.MatchString(req.EngineNo) {
		return errors.New("invalid engine no")
	}
	if req.ChassisNo != "" && !aiReg.MatchString(req.ChassisNo) {
		return errors.New("invalid chassis no")
	}

	return
}
