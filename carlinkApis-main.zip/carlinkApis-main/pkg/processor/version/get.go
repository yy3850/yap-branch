package version

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"

	"github.com/gin-gonic/gin"
)

func GetVersions(c *gin.Context) {
	var req params.GetVersionPayload
	var res params.GetVersionListResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	versionList, err := operation.GetVersionList(req.IsLatest)
	if err != nil {
		processor.ErrorResponse(c, nil, 400, err.Error())
		return
	}

	var versionResp []*params.VersionDetail
	for _, version := range versionList {
		versionResp = append(versionResp, &params.VersionDetail{
			VersionId:   version.VersionID,
			VersionName: version.VersionName,
			Desc:        version.Desc,
		})
	}

	res.Versions = versionResp
	res.IsSuccess = true
	c.JSON(200, res)
}
