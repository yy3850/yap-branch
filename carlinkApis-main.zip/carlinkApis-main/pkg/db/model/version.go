package model

type Version struct {
	VersionID   uint64 `gorm:"primary_key;column:version_id;type:bigint;not null" json:"version_id"`
	VersionName string `gorm:"column:version_name;type:varchar(255);not null" json:"version_name"`
	Desc        string `gorm:"column:desc;type:varchar(255);not null" json:"desc"`
}
