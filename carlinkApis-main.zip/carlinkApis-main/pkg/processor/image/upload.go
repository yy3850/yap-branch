package image

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/external/s3"
	"carlink/pkg/logger"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"fmt"
	"github.com/gin-gonic/gin"
	"strconv"
)

func UploadImage(c *gin.Context) {
	var res params.UploadImageResponse
	res.IsSuccess = false

	err := admin.IsValidToken(c)
	if err != nil {
		processor.ErrorResponse(c, nil, 403, err.Error())
		return
	}

	// only allow file that < 10 mb
	c.Request.ParseMultipartForm(10 << 20)
	file, _, err := c.Request.FormFile("image")
	if err != nil {
		logger.ErrorLogger.Println(fmt.Sprintf("upload image failed. err: %+v", err.Error()))
		processor.ErrorResponse(c, nil, 400, err.Error())
		return
	}

	defer file.Close()

	carId := c.Request.FormValue("car_id")
	carInt, err := strconv.Atoi(carId)
	if err != nil {
		logger.ErrorLogger.Println(fmt.Sprintf("invalid car id: %+v", carId))
		processor.ErrorResponse(c, nil, 400, "invalid car id")
		return
	}

	currentCar, err := operation.GetCarWithObjectById(uint64(carInt))
	if err != nil || currentCar.CarId == 0 {
		processor.ErrorResponse(c, nil, 400, "car record not found")
		return
	}

	key := generateKey(carInt)
	//file = AddWaterMark(file)
	err = s3.UploadImage(file, key)
	if err != nil {
		logger.ErrorLogger.Println(fmt.Sprintf("upload image failed. err: %+v", err.Error()))
		processor.ErrorResponse(c, nil, 400, err.Error())
		return
	}

	res.Key = getUrl(key)
	res.IsSuccess = true
	c.JSON(200, res)
}
