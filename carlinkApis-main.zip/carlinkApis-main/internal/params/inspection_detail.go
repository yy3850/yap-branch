package params

type GetInspectionDetailPayload struct {
	InspectionDetailId uint64 `form:"inspection_detail_id" url:"inspection_detail_id"`
	TypeId             uint64 `form:"type_id" url:"type_id"`
	PartId             uint64 `form:"part_id" url:"part_id"`
	DetailId           uint64 `form:"detail_id" url:"detail_id"`
}

type GetInspectionDetailResponse struct {
	IsSuccess      bool              `json:"is_success"`
	InspectionType []*InspectionType `json:"inspection_details,omitempty"`
}

type InspectionType struct {
	InspectionTypeId uint64            `json:"inspection_type_id"`
	Name             string            `json:"name"`
	InspectionParts  []*InspectionPart `json:"inspection_parts"`
}

type InspectionPart struct {
	InspectionPartId uint64              `json:"inspection_part_id"`
	Name             string              `json:"name"`
	AvailableRemark  []*RemarkDetail     `json:"available_remarks"`
	InspectionDetail []*InspectionDetail `json:"inspection_details"`
}

type InspectionDetail struct {
	InspectionDetailId uint64 `json:"inspection_detail_id"`
	Name               string `json:"name"`
}

type RemarkDetail struct {
	RemarkId string `json:"remark_id"`
	Name     string `json:"name"`
}
