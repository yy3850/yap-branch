package bid

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"github.com/gin-gonic/gin"
)

func GetBids(c *gin.Context) {
	var req params.GetBidRequest
	var res params.GetBidResponse
	res.IsSuccess = false
	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	err := admin.IsValidToken(c)
	if err != nil {
		processor.ErrorResponse(c, nil, 403, err.Error())
		return
	}

	bidList, err := operation.GetBidList(req.AuctionId)
	if err != nil {
		processor.ErrorResponse(c, nil, 400, err.Error())
		return
	}

	var bidsResp []*params.BidDetail
	for _, bid := range bidList {
		bidsResp = append(bidsResp, &params.BidDetail{
			Price: bid.Price,
			UserDetail: &params.UserDetail{
				UserId:   bid.UserId,
				UserName: bid.UserName,
			},
		})
	}

	res.BidList = bidsResp
	res.IsSuccess = true
	c.JSON(200, res)
}
