package params

type GetCarImages struct {
	CarImageId   uint64 `form:"car_image_id"`
	CarId        uint64 `form:"car_id"json:"car_id" binding:"required"`
	CarImageType uint64 `form:"image_type"`
}

type UpsertCarImagesPayload struct {
	CarId        uint64      `json:"car_id"`
	ImageDetails []*CarImage `json:"image_details"`
}

type DeleteCarImagesPayload struct {
	CarImageIds []uint64 `json:"car_image_ids"`
}

type CarImageResponse struct {
	IsSuccess bool        `json:"is_success"`
	CarId     uint64      `json:"car_id,omitempty"`
	Images    []*CarImage `json:"images,omitempty"`
}

type CarImage struct {
	CarImageId     uint64 `json:"car_image_id"` // only for get response
	CarImageTypeId uint64 `json:"image_type"`
	Url            string `json:"url"`
	Remark         string `json:"remark"`
	CreatedBy      uint64 `json:"created_by"`
}
