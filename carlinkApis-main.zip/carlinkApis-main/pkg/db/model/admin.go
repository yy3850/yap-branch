package model

type AdminTab struct {
	AdminId   uint64 `gorm:"primary_key;column:admin_id;type:bigint;not null" json:"admin_id"`
	RoleId    uint64 `gorm:"column:role_id;type:bigint;not null" json:"role_id"`
	CompanyId uint64 `gorm:"column:company_id;type:tinyint;not null" json:"company_id"`
	UserName  string `gorm:"column:username;type:varchar(255);not null" json:"username"`
	Name      string `gorm:"column:name;type:varchar(255);not null" json:"name"`
	Email     string `gorm:"column:email;type:varchar(255);not null" json:"email"`
	Password  string `gorm:"column:password;type:varchar(255);not null" json:"password"`
	Salt      string `gorm:"column:salt;type:varchar(255);not null" json:"salt"`
	Token     string `gorm:"column:token;type:varchar(255);not null" json:"token"`
}
