package params

type GetCarRequest struct {
	CarId     uint64  `form:"car_id"json:"car_id,omitempty"`
	KeyWords  string  `form:"keywords"json:"keywords,omitempty"`
	BrandId   uint64  `form:"brand_id"json:"brand_id,omitempty"`
	ModelId   uint64  `form:"model_id"json:"model_id,omitempty"`
	CreatedBy uint64  `form:"created_by"json:"created_by,omitempty"`
	Status    string  `form:"status"json:"status,omitempty"`
	Offset    *uint64 `form:"offset"json:"offset,omitempty"`
	Limit     *uint64 `form:"limit"json:"limit,omitempty"`
}

type GetCarResponse struct {
	IsSuccess  bool         `json:"is_success"`
	CarDetails []*CarDetail `json:"car_details,omitempty"`
	Pagination *Pagination  `json:"pagination,omitempty"`
}

type Pagination struct {
	Offset *uint64 `json:"offset,omitempty"`
	Limit  *uint64 `json:"limit,omitempty"`
}

type CreateCarPayload struct {
	UserId           uint64  `json:"user_id" binding:"required"`
	LicensePlateNo   string  `json:"license_plate_no" binding:"required"`
	Mileage          uint64  `json:"mileage" binding:"required"`
	ManufactureYear  uint64  `json:"manufacture_year" binding:"required"`
	RegistrationDate uint32  `json:"registration_date" binding:"required"`
	BrandId          uint64  `json:"brand_id" binding:"required"`
	ModelId          uint64  `json:"model_id" binding:"required"`
	VariantId        uint64  `json:"variant_id" binding:"required"`
	TransmissionId   uint64  `json:"transmission_id" binding:"required"`
	EngineNo         string  `json:"engine_no" binding:"required"`
	EngineCapacity   string  `json:"engine_capacity" binding:"required"`
	ChassisNo        string  `json:"chassis_no" binding:"required"`
	ColorId          uint64  `json:"color_id" binding:"required"`
	FuelType         string  `json:"fuel_type" binding:"required"`
	ExistingLoan     bool    `json:"existing_loan"`
	NoOfSeat         uint64  `json:"no_of_seat" binding:"required"`
	StateId          uint64  `json:"state_id" binding:"required"`
	RegistrationType string  `json:"registration_type" binding:"required"`
	SellWithPlateNo  bool    `json:"sell_with_plate_no"`
	AuctionRemark    string  `json:"auction_remark" binding:"required"`
	Price            float64 `json:"price" binding:"required"`
}

type CarResponse struct {
	IsSuccess bool       `json:"is_success"`
	CarDetail *CarDetail `json:"car_detail"`
}

type UpdateCarPayload struct {
	CarId            uint64  `json:"car_id" binding:"required"`
	UserId           uint64  `json:"user_id"`
	LicensePlateNo   string  `json:"license_plate_no"`
	Mileage          uint64  `json:"mileage"`
	ManufactureYear  uint64  `json:"manufacture_year"`
	RegistrationDate uint32  `json:"registration_date"`
	BrandId          uint64  `json:"brandId"`
	ModelId          uint64  `json:"model_id"`
	VariantId        uint64  `json:"variant_id"`
	TransmissionId   uint64  `json:"transmission_id"`
	EngineNo         string  `json:"engine_no"`
	EngineCapacity   string  `json:"engine_capacity"`
	ChassisNo        string  `json:"chassis_no"`
	ColorId          uint64  `json:"color_id"`
	FuelType         string  `json:"fuel_type"`
	ExistingLoan     *bool   `json:"existing_loan"`
	NoOfSeat         uint64  `json:"no_of_seat"`
	StateId          uint64  `json:"state_id"`
	RegistrationType string  `json:"registration_type"`
	SellWithPlateNo  *bool   `json:"sell_with_plate_no"`
	AuctionRemark    string  `json:"auction_remark"`
	Price            float64 `json:"price"`
}

type UpdataCarStatusPayload struct {
	CarId  uint64 `json:"car_id"`
	Status string `json:"status"`
}

type DeleteCarPayload struct {
	CarId uint64 `json:"car_id"`
}

type CarDetail struct {
	CarId            uint64               `json:"car_id"`
	UserId           uint64               `json:"user_id"`
	LicensePlateNo   string               `json:"license_plate_no"`
	Mileage          uint64               `json:"mileage"`
	ManufactureYear  uint64               `json:"manufacture_year"`
	RegistrationDate uint32               `json:"registration_date"`
	Brand            *BrandDetail         `json:"brand"`
	Model            *ModelDetail         `json:"model"`
	Variant          *VariantDetail       `json:"variant"`
	Transmission     *TransmissionDetail  `json:"transmission"`
	EngineNo         string               `json:"engine_no"`
	EngineCapacity   string               `json:"engine_capacity"`
	ChassisNo        string               `json:"chassis_no"`
	Color            *ColorDetail         `json:"color"`
	FuelType         string               `json:"fuel_type"`
	ExistingLoan     bool                 `json:"existing_loan"`
	NoOfSeat         uint64               `json:"no_of_seat"`
	State            *StateDetail         `json:"state"`
	RegistrationType string               `json:"registration_type"`
	SellWithPlateNo  bool                 `json:"sell_with_plate_no"`
	AuctionRemark    string               `json:"auction_remark"`
	Price            float64              `json:"price"`
	CreateBy         uint64               `json:"create_by"`
	CreateTime       int64                `json:"create_time"`
	DisplayUrl       string               `json:"display_url"`
	Stickers         []*CarStickerDetails `json:"stickers,omitempty"`
	Status           string               `json:"status,omitempty"`
}
