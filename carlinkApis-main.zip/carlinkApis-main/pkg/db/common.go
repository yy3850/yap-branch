package db

type CommonCondition struct {
	Limit       *uint64
	Offset      *uint64
	OrderBy     *string
	IsAscending *bool
}
