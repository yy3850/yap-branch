package user

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"github.com/gin-gonic/gin"
)

func GetUsers(c *gin.Context) {
	var req params.GetUserParam
	var res params.GetUserResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	err := admin.IsValidToken(c)
	if err != nil {
		processor.ErrorResponse(c, req, 403, err.Error())
		return
	}

	users, err := operation.GetUserList(req.UserId)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	var userResp []*params.UserDetail
	for _, user := range users {
		userResp = append(userResp, &params.UserDetail{
			UserId:   user.UserId,
			UserName: user.UserName,
			Name:     user.Name,
			Email:    user.Email,
			Contact:  user.Contact,
			Image:    user.Image,
		})
	}

	res.Users = userResp
	res.IsSuccess = true
	c.JSON(200, res)
}
