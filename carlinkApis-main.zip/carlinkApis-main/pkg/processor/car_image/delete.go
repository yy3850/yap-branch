package car_image

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/logger"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"fmt"
	"github.com/gin-gonic/gin"
)

func DeleteCarImage(c *gin.Context) {
	var req params.DeleteCarImagesPayload
	var res params.CarImageResponse
	res.IsSuccess = false
	if err := c.ShouldBindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	operator, err := admin.GetAdminDetail(c)
	if err != nil || operator.AdminId == 0 {
		processor.ErrorResponse(c, req, 403, "authentication failed")
		return
	}

	err = operation.DeleteCarImages(req.CarImageIds)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	res.IsSuccess = true

	logger.InfoLogger.Println(fmt.Sprintf("Car images deleted. %+v", req))
	c.JSON(200, res)
}
