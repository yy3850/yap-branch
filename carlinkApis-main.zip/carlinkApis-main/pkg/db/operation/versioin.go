package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	VersionTab = "version"
)

func GetVersionList(isLatest bool) (versions []*model.Version, err error) {
	db := db.CarLinkDB.Table(VersionTab)

	db = db.Order("version.version_id desc")

	if isLatest {
		db = db.Limit(1)
	}

	res := db.Find(&versions)
	return versions, res.Error
}
