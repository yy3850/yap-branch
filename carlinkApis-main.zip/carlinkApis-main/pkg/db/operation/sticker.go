package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	StickerTab           = "sticker"
	StickerStatusDeleted = 1
)

func GetStickerList(stickerId uint64) (stickers []*model.Sticker, err error) {
	db := db.CarLinkDB.Table(StickerTab)
	if stickerId != 0 {
		db = db.Where("sticker_id = ?", stickerId)
	}

	db = db.Where("deleted != ?", StickerStatusDeleted)
	res := db.Find(&stickers)
	return stickers, res.Error
}
