package model

type Sticker struct {
	StickerId   uint64 `gorm:"primary_key;column:sticker_id;type:bigint;not null" json:"sticker_id"`
	Description string `gorm:"column:description;type:bigint;not null" json:"description"`
	ImageLink   string `gorm:"column:s3_image;type:varchar(255);not null" json:"s3_image"`
}
