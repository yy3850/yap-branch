package car_inspection

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"carlink/pkg/logger"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"fmt"
	"strings"
	"sync"

	"github.com/gin-gonic/gin"
)

func UpsertCarInspection(c *gin.Context) {
	var req params.UpsertCarInspectionPayload
	var res params.CarInspectionResponse
	res.IsSuccess = false
	if err := c.ShouldBindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	operator, err := admin.GetAdminDetail(c)
	if err != nil || operator.AdminId == 0 {
		processor.ErrorResponse(c, req, 403, "authentication failed")
		return
	}

	if req.CarId == 0 {
		processor.ErrorResponse(c, req, 400, "invalid car id")
		return
	}

	currentCar, err := operation.GetCarById(req.CarId)
	if err != nil || currentCar.CarId == 0 {
		processor.ErrorResponse(c, req, 400, "car record not found")
		return
	}

	if currentCar.CreatedBy != operator.AdminId && operator.RoleId != 1 {
		processor.ErrorResponse(c, req, 403, "only creator or admin can update")
		return
	}

	carInspestionModels := []*model.CarInspection{}
	var wg sync.WaitGroup
	for _, carInspectionReq := range req.CarInspectionDetails {
		wg.Add(1)
		carInspestionModels = append(carInspestionModels, &model.CarInspection{
			CarInspectionId:    carInspectionReq.CarInspectionId,
			CarId:              req.CarId,
			InspectionDetailId: carInspectionReq.InspectionDetailId,
			Remarks:            strings.Trim(strings.Replace(fmt.Sprint(carInspectionReq.RemarksId), " ", ",", -1), "[]"),
			Images:             strings.Join(carInspectionReq.ImagesUrl, ","),
		})
	}

	operation.UpsertCarInspections(carInspestionModels, &wg)

	carInspestionResps, err := operation.GetCarInspectionList(req.CarId, 0)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	res.CarId = req.CarId
	res.CarInspectionDetails = ConvertCarInspectionResponse(carInspestionResps)
	res.IsSuccess = true
	logger.InfoLogger.Println(fmt.Sprintf("Car inspection upserted. %+v", req))

	c.JSON(200, res)
}
