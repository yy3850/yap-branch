package car_inspection

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/processor"
	"strings"
)

func ConvertCarInspectionResponse(carInspectionList []*model.CarInspection) (carInspestionResps []*params.CarInspectionDetail) {
	for _, carInspection := range carInspectionList {
		remarks := []*params.RemarkDetail{}

		if carInspection.Remarks != "" {
			for _, r := range strings.Split(carInspection.Remarks, ",") {
				remarks = append(remarks, &params.RemarkDetail{
					RemarkId: r,
					Name:     processor.InspectionRemarkMap[r],
				})
			}
		}

		imageStringList := []string{}
		if carInspection.Images != "" {
			imageStringList = strings.Split(carInspection.Images, ",")
		}
		carInspestionResps = append(carInspestionResps, &params.CarInspectionDetail{
			CarInspectionId:    carInspection.CarInspectionId,
			InspectionDetailId: carInspection.InspectionDetailId,
			ImagesUrl:          imageStringList,
			Remarks:            remarks,
		})
	}
	return
}
