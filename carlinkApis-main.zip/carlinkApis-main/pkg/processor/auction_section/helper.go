package auction_section

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"time"
)

func ConvertAuctionSectionResponse(AuctionSectionDetail []*model.AuctionSection) (aSectionResp []*params.AuctionSectionDetail) {
	for _, auctionSection := range AuctionSectionDetail {
		aSectionResp = append(aSectionResp, &params.AuctionSectionDetail{
			AuctionSectionId: uint64(auctionSection.AuctionSectionId),
			TotalVehicles:    int64(auctionSection.TotalAuction),
			Status:           getStatus(auctionSection.StartTimestamp, auctionSection.EndTimestamp),
			StartTime:        auctionSection.StartTimestamp,
			EndTime:          auctionSection.EndTimestamp,
		})
	}
	return
}

func getStatus(stratTime int64, endTime int64) (result string) {
	tNow := time.Now().Unix()
	result = "Ended"
	if stratTime == 0 || endTime == 0 || tNow >= endTime {
		return
	}

	if stratTime > tNow {
		result = "In Auction"
	} else {
		result = "Live"
	}
	return
}

func ConvertSingleAuctionSectionResponse(auctionSection *model.AuctionSection) *params.AuctionSectionDetail {
	return &params.AuctionSectionDetail{
		AuctionSectionId: uint64(auctionSection.AuctionSectionId),
		StartTime:        auctionSection.StartTimestamp,
		EndTime:          auctionSection.EndTimestamp,
	}
}
