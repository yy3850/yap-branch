package params

type UpsertCarInspectionPayload struct {
	CarId                uint64                 `json:"car_id" binding:"required"`
	CarInspectionDetails []*CarInspectionDetail `json:"car_inspection_details" binding:"required"`
}

type GetCarInspectionPayload struct {
	CarId              uint64 `form:"car_id"json:"car_id" binding:"required"`
	InspectionDetailId uint64 `form:"inspection_detail_id"json:"inspection_detail_id"`
}

type DeleteCarInspection struct {
	CarInspectionIds []uint64 `json:"car_inspection_ids"`
}

type CarInspectionResponse struct {
	CarId                uint64                 `json:"car_id"`
	CarInspectionDetails []*CarInspectionDetail `json:"car_inspection_details"`
	IsSuccess            bool                   `json:"is_success"`
}

type CarInspectionDetail struct {
	CarInspectionId    uint64          `json:"car_inspection_id"`
	InspectionDetailId uint64          `json:"inspection_detail_id"`
	ImagesUrl          []string        `json:"images_urls"`
	RemarksId          []uint64        `json:"remark_ids,omitempty"` // for upsert
	Remarks            []*RemarkDetail `json:"remarks"`
}
