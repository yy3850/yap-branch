package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
	"fmt"
	"time"
)

const (
	CarTab           = "car"
	CarStatusDeleted = 1

	CarStatusAvailable = "Available"
	CarStatusPending   = "Pending"
	CarStatusInAuction = "In Auction "
)

func GetCarListByIds(carIds []uint64) (cars []*model.Car, err error) {
	db := db.CarLinkDB.Table(CarTab)
	db = db.Where("car_id in ?", carIds)
	db = db.Where("deleted != ?", CarStatusDeleted)
	res := db.Find(&cars)
	return cars, res.Error
}

func GetCarById(carId uint64) (car *model.Car, err error) {
	db := db.CarLinkDB.Table(CarTab)
	db = db.Where("car_id = ?", carId)
	db = db.Where("deleted != ?", CarStatusDeleted)
	res := db.Find(&car)
	return car, res.Error
}

func GetCarWithObjectById(carId uint64) (car *model.CarWithObject, err error) {
	db := db.CarLinkDB.Table(CarTab)
	db.Model(&car).Select("car.*, brand.name as brand_name,model.name as model_name,state.state as state_name," +
		"variant.variant as variant_name,transmission.name as transmission_name,color.name as color_name").
		Joins("left join brand on car.brand_id_copy = brand.brand_id").
		Joins("left join model on car.model_id = model.model_id").
		Joins("left join state on car.state_id = state.state_id").
		Joins("left join variant on car.variant_id = variant.variant_id").
		Joins("left join color on car.color_id = color.color_id").
		Joins("left join transmission on car.transmission_id = transmission.transmission_id")

	db = db.Where("car.car_id = ?", carId)
	db = db.Where("car.deleted != ?", CarStatusDeleted)
	res := db.Find(&car)
	return car, res.Error
}

func InsertCar(car *model.Car) (*model.Car, error) {
	db := db.CarLinkDB.Table(CarTab)
	res := db.Create(car)

	if res.Error != nil {
		return nil, res.Error
	}
	return car, nil
}

func UpdateCar(car *model.Car) (*model.Car, error) {
	db := db.CarLinkDB.Table(CarTab)
	res := db.Where("car_id=?", car.CarId).Updates(&car)

	if res.Error != nil {
		return nil, res.Error
	}
	return car, nil
}

func UpdateCarsStatus(carIds []uint64, toStatus string) error {
	db := db.CarLinkDB.Table(CarTab)
	currentTime := time.Now().Unix()
	res := db.Where("car_id in ?", carIds).Updates(model.Car{Status: toStatus, UpdateTime: currentTime})
	if res.Error != nil {
		return res.Error
	}
	return nil
}

func DeleteCar(carId uint64) error {
	db := db.CarLinkDB.Table(CarTab)
	res := db.Where("car_id=?", carId).Update("deleted", CarStatusDeleted)
	if res.Error != nil {
		return res.Error
	}
	return nil
}

func GetCarWithObject(condition *model.Car, commonCond *db.CommonCondition, keywords string) (car []*model.CarWithObject, err error) {
	db := db.CarLinkDB.Table(CarTab)
	var result []*model.CarWithObject

	db.Model(&car).Select("car.*, brand.name as brand_name,model.name as model_name,state.state as state_name," +
		"variant.variant as variant_name,transmission.name as transmission_name,color.name as color_name").
		Joins("left join brand on car.brand_id_copy = brand.brand_id").
		Joins("left join model on car.model_id = model.model_id").
		Joins("left join state on car.state_id = state.state_id").
		Joins("left join variant on car.variant_id = variant.variant_id").
		Joins("left join color on car.color_id = color.color_id").
		Joins("left join transmission on car.transmission_id = transmission.transmission_id")

	db = db.Where("car.deleted != ?", CarStatusDeleted)

	if condition.CarId != 0 {
		db = db.Where("car.car_id = ?", condition.CarId)
	}

	if keywords != "" {
		db = db.Where("car.lisence_plate_no LIKE ?", fmt.Sprintf("%%%+v%%", keywords)).
			Or("brand.name LIKE ?", fmt.Sprintf("%%%+v%%", keywords)).
			Or("model.name LIKE ?", fmt.Sprintf("%%%+v%%", keywords))
	}

	if condition.ModelId != 0 {
		db = db.Where("car.model_id = ?", condition.ModelId)
	}

	if condition.BrandId != 0 {
		db = db.Where("car.brand_id_copy = ?", condition.BrandId)
	}

	if condition.CreatedBy != 0 {
		db = db.Where("car.created_by = ?", condition.CreatedBy)
	}

	if condition.Status != "" {
		db = db.Where("car.status = ?", condition.Status)
	}

	db = db.Order("car.car_id desc")

	if commonCond.Limit != nil {
		db = db.Limit(int(*commonCond.Limit))
	}

	if commonCond.Offset != nil {
		db = db.Offset(int(*commonCond.Offset))
	}

	db.Find(&result)

	return result, err
}
