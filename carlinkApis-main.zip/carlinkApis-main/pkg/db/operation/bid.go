package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	BidTab           = "bid"
	BidStatusDeleted = 1
)

func GetBidList(auctionID uint64) (bids []*model.Bid, err error) {
	db := db.CarLinkDB.Table(BidTab)
	db.Model(&bids).Select("bid.bid_id, bid.current_selling_price as price,u.users_id as user_id, u.name").
		Joins("left join carlink.users as u using (users_id)")

	if auctionID != 0 {
		db = db.Where("auction_id = ?", auctionID)
	}

	db = db.Where("bid.deleted != ?", BidStatusDeleted)
	res := db.Find(&bids)
	return bids, res.Error
}
