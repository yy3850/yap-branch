package s3

import (
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
)

var (
	s3session *s3.S3
)

const (
	BUCKET_NAME = "carlinkbucket"
	REGION      = "ap-southeast-1"
)

func init() {
	s3session = s3.New(session.Must(session.NewSession(
		&aws.Config{
			Region: aws.String(REGION),
		})))
}
