package model

type InspectionRemark struct {
	Id   uint64 `gorm:"primary_key;column:id;type:bigint;not null" json:"id"`
	Name string `gorm:"column:name;type:varchar(255);not null" json:"name"`
}
