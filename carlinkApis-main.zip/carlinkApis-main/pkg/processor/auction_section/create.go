package auction_section

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"carlink/pkg/logger"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"fmt"
	"time"

	"github.com/gin-gonic/gin"
)

func CreateAuctionSection(c *gin.Context) {
	var req params.CreateAuctionSectionPayload
	var res params.AuctionSectionResponse
	res.IsSuccess = false
	if err := c.ShouldBindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	creator, err := admin.GetAdminDetail(c)
	if err != nil || creator.AdminId == 0 {
		processor.ErrorResponse(c, req, 404, "authentication failed")
		return
	}

	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	loc, _ := time.LoadLocation("Asia/Singapore")
	sTime := time.Unix(req.StartTime, 0).In(loc)
	eTime := time.Unix(req.EndTime, 0).In(loc)

	_, err = operation.InsertAuctionSection(&model.AuctionSection{
		StartTimestamp: req.StartTime,
		EndTimestamp:   req.EndTime,
		Date:           sTime.Format("2006-01-02"),
		StartTime:      sTime.Format("15:04:05"),
		EndTime:        eTime.Format("15:04:05"),
	})
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	//res.AuctionSectionDetails = ConvertAuctionSectionResponse([]*model.AuctionSection{auctionSectionList})
	res.IsSuccess = true

	logger.InfoLogger.Println(fmt.Sprintf("New auction section created. %+v", req))
	c.JSON(200, res)
}
