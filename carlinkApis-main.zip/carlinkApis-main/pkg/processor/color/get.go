package color

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"github.com/gin-gonic/gin"
)

func GetColor(c *gin.Context) {
	var req params.GetColorParam
	var res params.GetColorResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	err := admin.IsValidToken(c)
	if err != nil {
		processor.ErrorResponse(c, nil, 403, err.Error())
		return
	}

	colors, err := operation.GetColorList(req.ColorId)
	if err != nil {
		processor.ErrorResponse(c, nil, 400, err.Error())
		return
	}

	var colorsResp []*params.ColorDetail
	for _, color := range colors {
		colorsResp = append(colorsResp, &params.ColorDetail{
			ColorId:   color.ColorId,
			ColorName: color.ColorName,
		})
	}

	res.Colors = colorsResp
	res.IsSuccess = true
	c.JSON(200, res)
}
