package processor

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"fmt"
	"github.com/gin-gonic/gin"
	"math/rand"
)

var (
	InspectionRemarkMap     map[string]string
	AuctionStatusMap        map[uint64]string
	AuctionStringStatusMap  map[string]uint64
	CarImageIDMandatoryList map[uint64]string
)

func init() {
	// init inspection remark map
	InspectionRemarkMap = make(map[string]string)
	remarks, _ := operation.GetInspectionRemarkList(0)
	for _, v := range remarks {
		InspectionRemarkMap[fmt.Sprintf("%+v", v.Id)] = v.Name
	}

	// init auction status map
	AuctionStatusMap = make(map[uint64]string)
	AuctionStringStatusMap = make(map[string]uint64)

	AuctionStatusMap[1] = "InAuction"
	AuctionStatusMap[2] = "Live"
	AuctionStatusMap[3] = "Ended"
	AuctionStatusMap[4] = "Completed"
	AuctionStatusMap[5] = "Rejected"

	for k, v := range AuctionStatusMap {
		AuctionStringStatusMap[v] = k
	}

	isMandatory := 1
	// init car image id mandatory list
	CarImageIDMandatoryList, _ = operation.GetCarImageTypeIdList(&isMandatory)
}

func GetOtp() int {
	return rand.Intn(9999-1000) + 1000
}

func ErrorResponse(c *gin.Context, req interface{}, code int, msg string) {
	resp := params.ErrorResponse{
		IsSuccess: false,
		ErrorMsg:  msg,
	}
	c.JSON(code, resp)
}
