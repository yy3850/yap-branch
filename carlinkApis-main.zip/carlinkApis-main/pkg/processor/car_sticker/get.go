package car_sticker

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"github.com/gin-gonic/gin"
)

func GetCarSticker(c *gin.Context) {
	var req params.GetCarStickers
	var res params.CarStickerResponse
	res.IsSuccess = false
	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	err := admin.IsValidToken(c)
	if err != nil {
		processor.ErrorResponse(c, req, 403, err.Error())
		return
	}

	carImages, err := operation.GetCarStickerList(&model.CarSticker{
		CarStickerId: req.CarStickerId,
		CarId:        req.CarId,
		StickerId:    req.StickerId,
	})
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	res.StickerDetails = ConvertCarStickerResponse(carImages)
	res.CarId = req.CarId
	res.IsSuccess = true
	c.JSON(200, res)
}
