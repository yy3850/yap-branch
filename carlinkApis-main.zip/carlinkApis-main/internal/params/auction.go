package params

type GetAuctionParam struct {
	AuctionId        uint64 `form:"auction_id"json:"auction_id"`
	CarId            uint64 `form:"car_id"json:"car_id"`
	AuctionSectionId uint64 `form:"auction_section_id"json:"auction_section_id"`
	AuctionStatusId  uint64 `form:"auction_status_id"json:"auction_status_id"`
}

type CreateAuctionPayload struct {
	CarIds           []uint64 `json:"car_ids" binding:"required"`
	AuctionSectionId uint64   `json:"auction_section_id" binding:"required"`
}

type AuctionResponse struct {
	IsSuccess     bool             `json:"is_success"`
	AuctionDetail []*AuctionDetail `json:"auction_section_details,omitempty"`
}

type AuctionDetail struct {
	AuctionId      uint64                `json:"auction_id"`
	Car            *CarDetail            `json:"car"`
	AuctionSection *AuctionSectionDetail `json:"auction_section"`
	StartingPrice  float64               `json:"starting_price"`
	AuctionStatus  string                `json:"auction_status"`
	DepositAmount  float64               `json:"deposit_amount"`
	AuctionRemark  string                `json:"auction_remark"`
	Creator        *UserDetail           `json:"creator"`
	TotalBid       int64                 `json:"total_bid"`
	FinalBid       float32               `json:"final_bid"`
	TotalBuyer     int64                 `json:"total_buyer"`
	Buyer          *UserDetail           `json:"buyer"`
	AuctionDate    int64                 `json:"auction_date"`
}
