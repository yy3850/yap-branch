package sticker

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"

	"github.com/gin-gonic/gin"
)

func GetSticker(c *gin.Context) {
	var req params.GetStickerParam
	var res params.GetStickerResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	// err := admin.IsValidToken(c)
	// if err != nil {
	// 	processor.ErrorResponse(c, req, 403, err.Error())
	// 	return
	// }

	stickers, err := operation.GetStickerList(req.StickerId)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	var stickerResp []*params.StickerDetail
	for _, sticker := range stickers {
		stickerResp = append(stickerResp, &params.StickerDetail{
			StickerId:   sticker.StickerId,
			Description: sticker.Description,
			ImageLink:   sticker.ImageLink,
		})
	}

	res.Stickers = stickerResp
	res.IsSuccess = true
	c.JSON(200, res)
}
