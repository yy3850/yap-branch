package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	BrandTab           = "brand"
	BrandStatusDeleted = 1
)

func GetBrandList(brandId uint64) (brands []*model.Brand, err error) {
	db := db.CarLinkDB.Table(BrandTab)
	if brandId != 0 {
		db = db.Where("brand_id = ?", brandId)
	}

	db = db.Where("deleted != ?", BrandStatusDeleted)
	res := db.Find(&brands)
	return brands, res.Error
}
