package movider

import (
	"github.com/movider/movider-go/client"
)

var (
	moviderClient *client.Client
)

const (
	apiKey    = "2HaVFfLsqKfGeevMtP6yYOVTSYi"
	apiSecret = "ubTNzI7s3JSkGLSXJhJvP1z8MT4CTS8kMQrjfr4L"
)

func init() {
	moviderClient = client.New(apiKey, apiSecret)
}
