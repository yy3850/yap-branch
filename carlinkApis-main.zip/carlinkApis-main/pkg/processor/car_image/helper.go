package car_image

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
)

func ConvertCarImageResponse(carImages []*model.CarImage) (results []*params.CarImage) {
	for _, carImage := range carImages {
		results = append(results, &params.CarImage{
			CarImageId:     carImage.CarImageId,
			CarImageTypeId: carImage.CarImageType,
			Url:            carImage.Url,
			Remark:         carImage.Remark,
			CreatedBy:      carImage.CreatedBy,
		})
	}
	return
}
