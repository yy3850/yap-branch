package params

type GetCarImageTypeParam struct {
	CarImageTypeId uint64 `form:"car_image_type_id"json:"car_image_type_id"`
	TypeName       string `form:"type_name"json:"type_name"`
}

type GetCarImageTypeResponse struct {
	IsSuccess     bool                  `json:"is_success"`
	CarImageTypes []*CarImageTypeDetail `json:"car_image_types,omitempty"`
}

type CarImageTypeDetail struct {
	TypeId      uint64 `json:"type_id"`
	TypeName    string `json:"type_name"`
	SubTypeName string `json:"sub_type_name"`
	IsMandatory bool   `json:"is_mandatory"`
	IsMultiple  bool   `json:"is_multiple"`
}
