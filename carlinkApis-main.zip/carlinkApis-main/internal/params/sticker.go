package params

type GetStickerParam struct {
	StickerId uint64 `form:"sticker_id"json:"sticker_id"`
}

type GetStickerResponse struct {
	IsSuccess bool             `json:"is_success"`
	Stickers  []*StickerDetail `json:"stickers,omitempty"`
}

type StickerDetail struct {
	StickerId   uint64 `json:"sticker_id"`
	Description string `json:"description"`
	ImageLink   string `json:"image_link"`
}
