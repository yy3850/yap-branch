package model

type CarImage struct {
	CarImageId   uint64 `gorm:"primary_key;column:car_image_id;type:bigint;not null" json:"car_image_id"`
	CarId        uint64 `gorm:"column:car_id;type:bigint;not null" json:"car_id"`
	CarImageType uint64 `gorm:"column:type_id;type:bigint;not null" json:"car_image_type"`
	Url          string `gorm:"column:image;type:varchar(255);not null" json:"url"`
	Remark       string `gorm:"column:remark;type:varchar(255);not null" json:"remark"`
	CreatedBy    uint64 `gorm:"column:created_by;type:bigint;not null" json:"created_by"`
}
