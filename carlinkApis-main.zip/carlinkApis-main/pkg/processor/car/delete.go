package car

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/logger"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"fmt"
	"github.com/gin-gonic/gin"
)

func DeleteCar(c *gin.Context) {
	var req params.DeleteCarPayload
	var res params.CarResponse
	res.IsSuccess = false
	if err := c.ShouldBindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	operator, err := admin.GetAdminDetail(c)
	if err != nil || operator.AdminId == 0 {
		processor.ErrorResponse(c, req, 403, "authentication failed")
		return
	}

	currentCar, err := operation.GetCarWithObjectById(req.CarId)
	if err != nil || currentCar.CarId == 0 {
		processor.ErrorResponse(c, req, 400, "retrieve car details failed")
		return
	}

	if currentCar.CreatedBy != operator.AdminId && operator.RoleId != 1 {
		processor.ErrorResponse(c, req, 403, "only creator or admin can delete")
		return
	}

	err = operation.DeleteCar(req.CarId)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	res.CarDetail = ConvertCarResponse(currentCar)
	res.IsSuccess = true

	logger.InfoLogger.Println(fmt.Sprintf("Car deleted. %+v", req))
	c.JSON(200, res)
}
