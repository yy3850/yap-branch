package model

type CarInspection struct {
	CarInspectionId    uint64 `gorm:"primary_key;column:car_inspection_id;type:bigint;not null" json:"car_inspection_id"`
	CarId              uint64 `gorm:"column:car_id;type:bigint;not null" json:"car_id"`
	InspectionDetailId uint64 `gorm:"column:inspection_detail_id;type:bigint;not null" json:"inspection_detail_id"`
	Remarks            string `gorm:"column:remarks;type:varchar(255);not null" json:"remarks"`
	Images             string `gorm:"column:images;type:varchar(255);not null" json:"images"`
}
