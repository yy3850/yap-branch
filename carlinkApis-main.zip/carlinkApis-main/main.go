package main

import "carlink/web"

func main() {
	web.Run()
}
