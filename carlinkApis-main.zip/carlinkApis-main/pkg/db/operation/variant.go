package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	VariantTab           = "variant"
	VariantStatusDeleted = 1
)

func GetVariantList(variantId uint64, modelId uint64) (variants []*model.Variant, err error) {
	db := db.CarLinkDB.Table(VariantTab)
	if variantId != 0 {
		db = db.Where("variant_id = ?", variantId)
	}
	if modelId != 0 {
		db = db.Where("model_id = ?", modelId)
	}
	db = db.Where("deleted != ?", VariantStatusDeleted)
	res := db.Find(&variants)
	return variants, res.Error
}
