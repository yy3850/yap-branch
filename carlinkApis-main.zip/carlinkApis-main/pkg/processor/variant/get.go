package variant

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"github.com/gin-gonic/gin"
)

func GetVariant(c *gin.Context) {
	var req params.GetVariantParam
	var res params.GetVariantResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	err := admin.IsValidToken(c)
	if err != nil {
		processor.ErrorResponse(c, req, 403, err.Error())
		return
	}

	variants, err := operation.GetVariantList(req.VariantId, req.ModelId)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	var variantResp []*params.VariantDetail
	for _, variant := range variants {
		variantResp = append(variantResp, &params.VariantDetail{
			VariantId:   variant.VariantId,
			VariantName: variant.VariantName,
		})
	}

	res.Variants = variantResp
	res.IsSuccess = true
	c.JSON(200, res)
}
