package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	UserTab           = "users"
	UserStatusDeleted = 1
)

func GetUserList(userId uint64) (users []*model.User, err error) {
	db := db.CarLinkDB.Table(UserTab)
	if userId != 0 {
		db = db.Where("users_id = ?", userId)
	}
	db = db.Where("deleted != ?", UserStatusDeleted)
	res := db.Find(&users)
	return users, res.Error
}

// return true if phone exist
func CheckContact(contact string) (result bool, err error) {
	db := db.CarLinkDB.Table(UserTab)
	db.Select("count(*)>0")
	db = db.Where("contact = ?", contact)
	res := db.Find(&result)
	return result, res.Error
}

// return true if email exist
func CheckEmail(email string) (result bool, err error) {
	db := db.CarLinkDB.Table(UserTab)
	db.Select("count(*)>0")
	db = db.Where("email = ?", email)
	res := db.Find(&result)
	return result, res.Error
}
