package model

type InspectionType struct {
	InspectionTypeId uint64 `gorm:"primary_key;column:inspection_type_id;type:bigint;not null" json:"inspection_type_id"`
	Name             string `gorm:"column:name;type:varchar(255);not null" json:"name"`
}

type InspectionPart struct {
	InspectionPartId  uint64 `gorm:"primary_key;column:inspection_part_id;type:bigint;not null" json:"inspection_part_id"`
	InspectionTypeId  uint64 `gorm:"column:inspection_type_id;type:bigint;not null" json:"inspection_type_id"`
	Name              string `gorm:"column:name;type:varchar(255);not null" json:"name"`
	AvailableRemarkId string `gorm:"column:available_remark_id;type:varchar(255);not null" json:"available_remark_id"`
}

type InspectionDetail struct {
	InspectionDetailId uint64 `gorm:"primary_key;column:inspection_detail_id;type:bigint;not null" json:"inspection_detail_id"`
	InspectionPartId   uint64 `gorm:"column:inspection_type_id;type:bigint;not null" json:"inspection_type_id"`
	Name               string `gorm:"column:name;type:varchar(255);not null" json:"name"`
}

type InspectionDetails struct {
	InspectionTypeId   uint64 `gorm:"primary_key;column:type_id;type:bigint;not null" json:"type_id"`
	InspectionPartId   uint64 `gorm:"column:part_id;type:bigint;not null" json:"part_id"`
	InspectionDetailId uint64 `gorm:"column:detail_id;type:bigint;not null" json:"detail_id"`
	TypeName           string `gorm:"column:type_name;type:varchar(255);not null" json:"type_name"`
	PartName           string `gorm:"column:part_name;type:varchar(255);not null" json:"part_name"`
	DetailName         string `gorm:"column:detail_name;type:varchar(255);not null" json:"detail_name"`
	AvailableRemarkId  string `gorm:"column:available_remark_id;type:varchar(255);not null" json:"available_remark_id"`
}
