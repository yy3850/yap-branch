package auction_section

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"

	"github.com/gin-gonic/gin"
)

func GetAuctionSections(c *gin.Context) {
	var req params.GetAuctionSectionParam
	var res params.AuctionSectionResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	// err := admin.IsValidToken(c)
	// if err != nil {
	// 	processor.ErrorResponse(c, req, 403, err.Error())
	// 	return
	// }

	auctionSectionList, err := operation.GetAuctionSectionList(req.AuctionSectionId, req.StartTime, req.EndTime)
	if err != nil {
		processor.ErrorResponse(c, nil, 400, err.Error())
		return
	}

	res.AuctionSectionDetails = ConvertAuctionSectionResponse(auctionSectionList)
	res.IsSuccess = true
	c.JSON(200, res)
}
