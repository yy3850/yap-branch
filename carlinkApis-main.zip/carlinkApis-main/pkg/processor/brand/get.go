package brand

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"github.com/gin-gonic/gin"
)

func GetBrands(c *gin.Context) {
	var req params.GetBrandRequest
	var res params.GetBrandResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	err := admin.IsValidToken(c)
	if err != nil {
		processor.ErrorResponse(c, nil, 403, err.Error())
		return
	}

	brands, err := operation.GetBrandList(req.BrandId)
	if err != nil {
		processor.ErrorResponse(c, nil, 400, err.Error())
		return
	}

	var brandsResp []*params.BrandDetail
	for _, brand := range brands {
		brandsResp = append(brandsResp, &params.BrandDetail{
			BrandId:   brand.BrandID,
			BrandName: brand.BrandName,
			//Logo:      []byte(brand.Logo), // image don't needed for add new car
		})
	}

	res.Brands = brandsResp
	res.IsSuccess = true
	c.JSON(200, res)
}
