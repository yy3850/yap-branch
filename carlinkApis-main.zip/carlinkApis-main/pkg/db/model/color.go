package model

type Color struct {
	ColorId   uint64 `gorm:"primary_key;column:color_id;type:bigint;not null" json:"color_id"`
	ColorName string `gorm:"column:name;type:varchar(255);not null" json:"name"`
}
