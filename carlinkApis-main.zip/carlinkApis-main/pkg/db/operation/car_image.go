package operation

import (
	"carlink/internal/params"
	"carlink/pkg/db"
	"carlink/pkg/db/model"
	"sync"
	"time"
)

const (
	CarImageTab          = "car_image"
	CarImageStatusActive = 0
)

func GetDisplayImageByCarId(carId uint64) string {
	var carImage model.CarImage
	db := db.CarLinkDB.Table(CarImageTab)
	db = db.Where("car_id = ?", carId)
	db = db.Where("type_id = ?", CarImageTypeDisplay)
	db = db.Where("deleted = ?", CarImageStatusActive)
	db.Find(&carImage)
	return carImage.Url
}

func GetCarImageMap(carId uint64, typeIds []uint64) (result map[uint64]bool, err error) {
	var carImage []*model.CarImage
	db := db.CarLinkDB.Table(CarImageTab)
	if carId != 0 {
		db = db.Where("car_id = ?", carId)
	}
	if len(typeIds) > 0 {
		db = db.Where("type_id in ?", typeIds)
	}
	db = db.Where("deleted = ?", CarImageStatusActive)
	res := db.Find(&carImage)
	result = make(map[uint64]bool)
	for _, v := range carImage {
		if v.Url != "" { // exclude empty url
			result[v.CarImageType] = true
		}
	}

	return result, res.Error
}

func GetCarImageList(condition *model.CarImage) (carImage []*model.CarImage, err error) {
	db := db.CarLinkDB.Table(CarImageTab)
	if condition.CarImageId != 0 {
		db = db.Where("car_image_id = ?", condition.CarImageId)
	}

	if condition.CarId != 0 {
		db = db.Where("car_id = ?", condition.CarId)
	}
	if condition.CarImageType != 0 {
		db = db.Where("type_id = ?", condition.CarImageType)
	}
	db = db.Where("deleted = ?", CarImageStatusActive)
	res := db.Find(&carImage)
	return carImage, res.Error
}

func UpsertCarImages(carId uint64, carImageReqs []*params.CarImage) {
	carImageMap := make(map[uint64]*model.CarImage)
	currentCarImage, _ := GetCarImageList(&model.CarImage{
		CarId: carId,
	})

	for _, carImage := range currentCarImage {
		carImageMap[carImage.CarImageType] = carImage
	}

	var wg sync.WaitGroup
	for _, carImageReq := range carImageReqs {
		wg.Add(1)
		newCarImageDetail := &model.CarImage{
			CarId:        carId,
			CarImageType: carImageReq.CarImageTypeId,
			Url:          carImageReq.Url,
			Remark:       carImageReq.Remark,
			CreatedBy:    carImageReq.CreatedBy,
		}
		// always do insert for others type
		if carImageMap[carImageReq.CarImageTypeId] == nil || carImageReq.CarImageTypeId == CarImageTypeOthers {
			go InsertCarImage(newCarImageDetail, &wg)
		} else {
			go UpdateCarImage(newCarImageDetail, &wg)
		}
	}
	wg.Wait()
	return
}

func InsertCarImage(carImage *model.CarImage, wg *sync.WaitGroup) (*model.CarImage, error) {
	defer wg.Done()
	db := db.CarLinkDB.Table(CarImageTab)
	res := db.Create(carImage)

	if res.Error != nil {
		return nil, res.Error
	}
	return carImage, nil
}

func UpdateCarImage(carImage *model.CarImage, wg *sync.WaitGroup) (*model.CarImage, error) {
	defer wg.Done()
	db := db.CarLinkDB.Table(CarImageTab)
	res := db.Where("car_id=? and type_id = ?", carImage.CarId, carImage.CarImageType).Updates(&carImage)

	if res.Error != nil {
		return nil, res.Error
	}
	return carImage, nil
}

func DeleteCarImages(carImageIds []uint64) error {
	db := db.CarLinkDB.Table(CarImageTab)
	res := db.Where("car_image_id in ?", carImageIds).Update("deleted", time.Now().Unix())
	if res.Error != nil {
		return res.Error
	}
	return nil
}
