package car_sticker

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
)

func ConvertCarStickerResponse(carStickers []*model.CarSticker) (results []*params.CarStickerDetails) {
	for _, carSticker := range carStickers {
		results = append(results, &params.CarStickerDetails{
			CarStickerId: carSticker.CarStickerId,
			StickerId:    carSticker.StickerId,
			IsActive:     carSticker.IsActive,
		})
	}
	return
}
