package car_inspection

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"

	"github.com/gin-gonic/gin"
)

func GetCarInspections(c *gin.Context) {
	var req params.GetCarInspectionPayload
	var res params.CarInspectionResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	// creator, err := admin.GetAdminDetail(c)
	// if err != nil || creator.AdminId == 0 {
	// 	processor.ErrorResponse(c, req, 403, "authentication failed")
	// 	return
	// }

	carInspectionList, err := operation.GetCarInspectionList(req.CarId, req.InspectionDetailId)
	if err != nil {
		processor.ErrorResponse(c, nil, 400, err.Error())
		return
	}

	res.CarId = req.CarId
	res.CarInspectionDetails = ConvertCarInspectionResponse(carInspectionList)
	res.IsSuccess = true
	c.JSON(200, res)
}
