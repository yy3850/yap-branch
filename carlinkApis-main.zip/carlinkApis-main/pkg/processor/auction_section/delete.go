package auction_section

import (
	"carlink/internal/params"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"github.com/gin-gonic/gin"
)

func DeleteAuctionSection(c *gin.Context) {
	var req params.DeleteAuctionSectionPayload
	var res params.AuctionResponse

	res.IsSuccess = false

	if err := c.ShouldBindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	operator, err := admin.GetAdminDetail(c)
	if err != nil || operator.AdminId == 0 {
		processor.ErrorResponse(c, req, 403, "authentication failed")
		return
	}

}
