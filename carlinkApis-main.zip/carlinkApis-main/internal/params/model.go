package params

type GetModelParam struct {
	ModelId uint64 `form:"model_id"json:"model_id"`
	BrandId uint64 `form:"brand_id"json:"brand_id" binding:"required"`
}

type GetModelResponse struct {
	IsSuccess bool           `json:"is_success"`
	ErrorMsg  string         `json:"err_msg,omitempty"`
	Models    []*ModelDetail `json:"models,omitempty"`
}

type ModelDetail struct {
	ModelId   uint64 `json:"model_id"`
	ModelName string `json:"model_name"`
}
