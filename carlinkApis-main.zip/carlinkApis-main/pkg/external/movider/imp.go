package movider

import (
	"fmt"
	"github.com/movider/movider-go/sms"
)

func SendSMS(recipientNo string, otp int) error {
	_, err := sms.Send(moviderClient, []string{
		recipientNo,
	}, getOtpString(otp), &sms.Params{})

	if err != nil {
		return err
	}
	return nil
}

func getOtpString(otp int) string {
	return fmt.Sprintf(":\nDear Carlink Customer, your OTP for registration is %+v.\n"+
		"\nUse this OTP to validate your registration.", otp)
}
