package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	AdminTab           = "admin"
	AdminStatusDeleted = 1
	RoldAdminId        = 1
)

func GetAdminByUserName(userName string) (admin model.AdminTab, err error) {
	db := db.CarLinkDB.Table(AdminTab)
	db = db.Where("username = ?", userName)
	db = db.Where("deleted != ?", AdminStatusDeleted)
	res := db.Find(&admin)
	return admin, res.Error
}

func GetAdminByToken(token string) (admin model.AdminTab, err error) {
	db := db.CarLinkDB.Table(AdminTab)
	db = db.Where("token = ?", token)
	db = db.Where("deleted != ?", AdminStatusDeleted)
	res := db.Find(&admin)
	return admin, res.Error
}

func UpdateAdmin(adminId uint64, condition *model.AdminTab) (err error) {
	db := db.CarLinkDB.Table(AdminTab)
	res := db.Where("admin_id=?", adminId).Updates(&condition)
	if res.Error != nil {
		return res.Error
	}

	return nil
}
