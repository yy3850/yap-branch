package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	TransmissionTab           = "transmission"
	TransmissionStatusDeleted = 1
)

func GetTransmissionList(transmissionId uint64) (transmissions []*model.Transmission, err error) {
	db := db.CarLinkDB.Table(TransmissionTab)
	if transmissionId != 0 {
		db = db.Where("transmission_id = ?", transmissionId)
	}

	db = db.Where("deleted != ?", TransmissionStatusDeleted)
	res := db.Find(&transmissions)
	return transmissions, res.Error
}
