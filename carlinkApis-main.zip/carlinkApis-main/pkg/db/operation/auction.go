package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	AuctionTab           = "auction"
	AuctionStatusDeleted = 1
)

func GetAuctionList(auctionId uint64, carId uint64, auctionSectionId uint64, status_id uint64) (auctions []*model.Auction, err error) {
	db := db.CarLinkDB.Table(AuctionTab)
	db.Model(&auctions).Select("auction.*, count( b.bid_id) as total_bid, max(b.current_selling_price) final_bid, " +
		"count(DISTINCT b.users_id) total_buyer, u.users_id as buyer_id, u.name as buyer_name, c.name as creator_name").
		Joins("left join carlink.bid as b using(auction_id)").
		Joins("left join carlink.users as u on u.users_id = auction.success_user_id").
		Joins("left join carlink.users as c on c.users_id = auction.created_by")

	if auctionSectionId != 0 {
		db = db.Where("auction_section_id = ?", auctionSectionId)
	}

	if carId != 0 {
		db = db.Where("car_id = ?", carId)
	}

	if status_id != 0 {
		db = db.Where("auction_status_id = ?", status_id)
	}

	if auctionId != 0 {
		db = db.Where("auction_id = ?", auctionId)
	}

	db = db.Where("auction.deleted != ?", AuctionStatusDeleted)
	db.Group("auction.auction_id")
	res := db.Find(&auctions)
	return auctions, res.Error
}

func InsertAuction(auctions []*model.Auction) ([]*model.Auction, error) {
	db := db.CarLinkDB.Table(AuctionTab)
	res := db.Omit("final_bid", "total_buyer", "total_bid", "creator_name", "buyer_id", "buyer_name").Create(auctions)

	if res.Error != nil {
		return nil, res.Error
	}
	return auctions, nil
}
