package params

type GetCarStickers struct {
	CarStickerId uint64 `form:"car_sticker_id" json:"car_sticker_id"`
	CarId        uint64 `form:"car_id"json:"car_id" binding:"required"`
	StickerId    uint64 `form:"sticker_id" json:"sticker_id"`
}

type UpsertCarStickersPayload struct {
	CarId          uint64               `json:"car_id"`
	StickerDetails []*CarStickerDetails `json:"sticker_details"`
}

type CarStickerResponse struct {
	CarId          uint64               `json:"car_id"`
	StickerDetails []*CarStickerDetails `json:"sticker_details"`
	IsSuccess      bool                 `json:"is_success"`
}

type CarStickerDetails struct {
	CarStickerId uint64 `json:"car_sticker_id"`
	StickerId    uint64 `json:"sticker_id"`
	IsActive     bool   `json:"is_active"`
}
