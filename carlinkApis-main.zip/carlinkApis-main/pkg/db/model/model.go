package model

type Model struct {
	ModelId   uint64 `gorm:"primary_key;column:model_id;type:bigint;not null" json:"model_id"`
	BrandId   uint64 `gorm:"column:brand_id;type:bigint;not null" json:"brand_id"`
	ModelName string `gorm:"column:name;type:varchar(255);not null" json:"name"`
}
