package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	CarImageTypeTab     = "car_image_type"
	CarImageTypeDeleted = 1
	CarImageTypeDisplay = 16
	CarImageTypeOthers  = 79
)

func GetCarImageTypeList(carImageTypeId uint64, typeName string) (carImageTypes []*model.CarImageType, err error) {
	db := db.CarLinkDB.Table(CarImageTypeTab)
	if carImageTypeId != 0 {
		db = db.Where("type_id = ?", carImageTypeId)
	}
	if typeName != "" {
		db = db.Where("type_name = ?", typeName)
	}

	db = db.Where("deleted != ?", CarImageTypeDeleted)
	res := db.Find(&carImageTypes)
	return carImageTypes, res.Error
}

func GetCarImageTypeIdList(isMandatory *int) (result map[uint64]string, err error) {
	var carImageTypes []*model.CarImageType
	result = make(map[uint64]string)
	db := db.CarLinkDB.Table(CarImageTypeTab)
	if isMandatory != nil {
		db = db.Where("is_mandatory = ?", isMandatory)
	}
	db = db.Where("deleted != ?", CarImageTypeDeleted)
	res := db.Find(&carImageTypes)
	for _, v := range carImageTypes {
		result[v.TypeId] = v.SubTypeName
	}

	return result, res.Error
}
