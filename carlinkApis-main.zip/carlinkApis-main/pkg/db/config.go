package db

import (
	"fmt"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var (
	CarLinkDB *gorm.DB
)

func init() {
	host := "carlinklive.cpkxqiojofjk.ap-southeast-1.rds.amazonaws.com:3306"
	dbUser := "carlink"
	dbPass := "carlink888"
	dbName := "carlink"
	//dbName := "carlink_live"

	conn := fmt.Sprintf("%+v:%+v@tcp(%+v)/%+v?charset=utf8&parseTime=True&loc=Local&timeout=10s&readTimeout=5s", dbUser, dbPass, host, dbName)

	db, err := gorm.Open(mysql.Open(conn))
	if err != nil {
		panic(err.Error())
	}

	CarLinkDB = db
}
