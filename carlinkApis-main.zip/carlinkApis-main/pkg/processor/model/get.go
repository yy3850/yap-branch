package model

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"github.com/gin-gonic/gin"
)

func GetModel(c *gin.Context) {
	var req params.GetModelParam
	var res params.GetModelResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	err := admin.IsValidToken(c)
	if err != nil {
		processor.ErrorResponse(c, req, 403, err.Error())
		return
	}

	models, err := operation.GetModelList(req.ModelId, req.BrandId)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	var modelResp []*params.ModelDetail
	for _, model := range models {
		modelResp = append(modelResp, &params.ModelDetail{
			ModelId:   model.ModelId,
			ModelName: model.ModelName,
		})
	}

	res.Models = modelResp
	res.IsSuccess = true
	c.JSON(200, res)
}
