package params

type GetUserParam struct {
	UserId uint64 `form:"user_id"json:"user_id"`
}

type GetUserResponse struct {
	IsSuccess bool          `json:"is_success"`
	Users     []*UserDetail `json:"users,omitempty"`
}

type UserDetail struct {
	UserId   uint64 `json:"user_id,omitempty"`
	UserName string `json:"user_name,omitempty"`
	Name     string `json:"name,omitempty"`
	Email    string `json:"email,omitempty"`
	Contact  uint64 `json:"contact,omitempty"`
	Image    string `json:"image,omitempty"`
}

type UserRegPayload struct {
	Contact   string `json:"contact,omitempty"`
	Name      string `json:"name,omitempty"`
	Email     string `json:"email,omitempty"`
	Password  string `json:"password,omitempty"`
	Password2 string `json:"password2,omitempty"`
	Nric      string `json:"nric, omitempty"`
}

type RegUserResponse struct {
	IsSuccess bool   `json:"is_success"`
	Message   string `json:"message"`
}
