package model

type Variant struct {
	VariantId   uint64 `gorm:"primary_key;column:variant_id;type:bigint;not null" json:"variant_id"`
	ModelId     uint64 `gorm:"column:model_id;type:bigint;not null" json:"model_id"`
	VariantName string `gorm:"column:variant;type:varchar(255);not null" json:"variant"`
}
