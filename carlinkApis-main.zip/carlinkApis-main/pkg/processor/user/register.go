package user

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/external/movider"
	"carlink/pkg/processor"
	"fmt"
	"github.com/gin-gonic/gin"
	"regexp"
)

func SendSMS(c *gin.Context) {
	err := movider.SendSMS("60189684088", processor.GetOtp())
	if err != nil {
		fmt.Println("ERR: ", err.Error())
	}
}

func Register(c *gin.Context) {

	var req params.UserRegPayload
	var res params.RegUserResponse
	res.IsSuccess = false

	// get payload
	if err := c.BindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	// process contact number
	re := regexp.MustCompile(`[^0-9.]`) //'/[^0-9.]+/';
	req.Contact = re.ReplaceAllString(req.Contact, "")
	if req.Contact[0] != '6' {
		req.Contact = "6" + req.Contact
	}

	// check email format
	reg := regexp.MustCompile(`\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*`)
	result := reg.MatchString(req.Email)
	if result == false {
		res.IsSuccess = false
		res.Message = "Invalid Email format"
		c.JSON(400, res)
		return
	}

	// compare passwords
	if req.Password != req.Password2 {
		res.IsSuccess = false
		res.Message = "Passwords do not match"
		c.JSON(400, res)
		return
	}

	// check phone exist
	phoneRes, err := operation.CheckContact(req.Contact)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}
	if phoneRes == true {
		//  phone already exist
		res.IsSuccess = false
		res.Message = "Phone number is already registered"
		c.JSON(400, res)
		return
	}

	// check email exist
	emailRes, err := operation.CheckEmail(req.Email)
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}
	if emailRes == true {
		//  email already exist
		res.IsSuccess = false
		res.Message = "Email is already registered"
		c.JSON(400, res)
		return
	}
	
	res.IsSuccess = true
	res.Message = "Success"
	c.JSON(http.StatusOK, res)

}




