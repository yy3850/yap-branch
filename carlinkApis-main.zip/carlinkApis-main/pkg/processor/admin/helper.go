package admin

import (
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"crypto/md5"
	"encoding/hex"
	"errors"
	"log"

	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

func GenerateToken(email string) string {
	hash, err := bcrypt.GenerateFromPassword([]byte(email), bcrypt.DefaultCost)
	if err != nil {
		log.Fatal(err)
	}
	hasher := md5.New()
	hasher.Write(hash)
	return hex.EncodeToString(hasher.Sum(nil))
}

func GetAdminDetail(c *gin.Context) (admin model.AdminTab, err error) {
	admin, err = operation.GetAdminByToken(c.Request.Header.Get("token"))
	return
}

func IsValidToken(c *gin.Context) (err error) {
	admin, err := operation.GetAdminByToken(c.Request.Header.Get("token"))
	if err != nil || admin.AdminId == 0 {
		return errors.New("invalid token")
	}
	return
}
