package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	StateTab           = "state"
	StateStatusDeleted = 1
)

func GetStateList(stateId uint64) (states []*model.State, err error) {
	db := db.CarLinkDB.Table(StateTab)

	if stateId != 0 {
		db = db.Where("state_id = ?", stateId)
	}

	db = db.Where("deleted != ?", StateStatusDeleted)
	res := db.Find(&states)
	return states, res.Error
}
