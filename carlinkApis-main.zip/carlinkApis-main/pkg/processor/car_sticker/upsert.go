package car_sticker

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"github.com/gin-gonic/gin"
)

func UpsertCarSticker(c *gin.Context) {
	var req params.UpsertCarStickersPayload
	var res params.CarStickerResponse
	res.IsSuccess = false
	if err := c.ShouldBindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	operator, err := admin.GetAdminDetail(c)
	if err != nil || operator.AdminId == 0 {
		processor.ErrorResponse(c, req, 403, "authentication failed")
		return
	}

	if req.CarId == 0 {
		processor.ErrorResponse(c, req, 400, "invalid car id")
		return
	}

	currentCar, err := operation.GetCarById(req.CarId)
	if err != nil || currentCar.CarId == 0 {
		processor.ErrorResponse(c, req, 400, "car record not found")
		return
	}

	var carStickersModel []*model.CarSticker
	for _, stickerReq := range req.StickerDetails {
		carStickersModel = append(carStickersModel, &model.CarSticker{
			CarId:     req.CarId,
			StickerId: stickerReq.StickerId,
			IsActive:  stickerReq.IsActive,
		})
	}

	operation.UpsertCarStickers(req.CarId, carStickersModel)

	carStickers, err := operation.GetCarStickerList(&model.CarSticker{CarId: req.CarId})
	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	res.CarId = req.CarId
	res.StickerDetails = ConvertCarStickerResponse(carStickers)
	res.IsSuccess = true
	c.JSON(200, res)
}
