package image

import (
	"carlink/pkg/external/s3"
	"fmt"
	"image"
	"image/draw"
	"image/jpeg"
	"image/png"
	"log"
	"mime/multipart"
	"os"
	"time"
)

func generateKey(carId int) string {
	tNow := time.Now().UnixMicro()
	return fmt.Sprintf("car/%+v/%+v.jpeg", carId, tNow)
}

func getUrl(key string) string {
	url := "https://%s.s3.%s.amazonaws.com/%s"
	return fmt.Sprintf(url, s3.BUCKET_NAME, s3.REGION, key)
}

func AddWaterMark(imageSource multipart.File) multipart.File {
	image1, err := os.Open("C:\\Users\\meipe\\Desktop\\carlinkAPIs\\pkg\\processor\\image\\Carlink-Logo-Watermark.png")
	if err != nil {
		log.Fatalf("failed to open: %s", err)
	}

	first, err := png.Decode(image1)
	if err != nil {
		log.Fatalf("failed to decode11: %s", err)
	}
	defer image1.Close()

	second, err := jpeg.Decode(imageSource)
	if err != nil {
		log.Fatalf("failed to decode22: %s", err)
	}

	offset := image.Pt(300, 200)
	b := first.Bounds()
	image3 := image.NewRGBA(b)
	draw.Draw(image3, b, first, image.ZP, draw.Src)
	draw.Draw(image3, second.Bounds().Add(offset), second, image.ZP, draw.Over)

	third, err := os.Create("result.jpg")
	if err != nil {
		log.Fatalf("failed to create: %s", err)
	}
	jpeg.Encode(third, image3, &jpeg.Options{jpeg.DefaultQuality})
	//defer third.Close()
	return third
}
