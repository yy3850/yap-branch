package model

//import "time"

type AuctionSection struct {
	AuctionSectionId uint   `gorm:"primary_key;column:auction_section_id;type:bigint;not null" json:"auction_section_id"`
	StartTimestamp   int64  `gorm:"column:start_timestamp;type:bigint;not null" json:"start_timestamp"`
	EndTimestamp     int64  `gorm:"column:end_timestamp;type:bigint;not null" json:"end_timestamp"`
	Date             string `gorm:"column:date;type:date;not null" json:"date"`
	StartTime        string `gorm:"column:start_time;type:time;not null" json:"start_time"`
	EndTime          string `gorm:"column:end_time;type:time;not null" json:"end_time"`
	TotalAuction     int
}
