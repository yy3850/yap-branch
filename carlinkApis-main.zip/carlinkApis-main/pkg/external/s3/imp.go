package s3

import (
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/service/s3"
	"mime/multipart"
)

func UploadImage(file multipart.File, key string) (err error) {
	_, err = s3session.PutObject(&s3.PutObjectInput{
		Body:   file,
		Bucket: aws.String(BUCKET_NAME),
		Key:    aws.String(key),
	})
	return
}
