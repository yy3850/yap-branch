package params

type GetColorParam struct {
	ColorId uint64 `form:"color_id"json:"color_id"`
}

type GetColorResponse struct {
	IsSuccess bool           `json:"is_success"`
	ErrorMsg  string         `json:"err_msg,omitempty"`
	Colors    []*ColorDetail `json:"colors,omitempty"`
}

type ColorDetail struct {
	ColorId   uint64 `json:"color_id"`
	ColorName string `json:"color_name"`
}
