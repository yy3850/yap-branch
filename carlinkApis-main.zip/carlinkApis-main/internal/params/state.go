package params

type GetStateParam struct {
	StateId uint64 `form:"state_id"json:"state_id"`
}

type GetStatesResponse struct {
	IsSuccess bool           `json:"is_success"`
	ErrorMsg  string         `json:"err_msg,omitempty"`
	States    []*StateDetail `json:"states,omitempty"`
}

type StateDetail struct {
	StateId   uint64 `json:"state_id"`
	StateName string `json:"state_name"`
	ShortForm string `json:"short_form"`
}
