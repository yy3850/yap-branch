package params

type GetTransmissionParam struct {
	TransmissionId uint64 `form:"transmission_id"json:"transmission_id"`
}

type GetTransmissionResponse struct {
	IsSuccess     bool                  `json:"is_success"`
	Transmissions []*TransmissionDetail `json:"transmissions,omitempty"`
}

type TransmissionDetail struct {
	TransmissionId uint64 `json:"transmission_id"`
	Name           string `json:"name"`
}
