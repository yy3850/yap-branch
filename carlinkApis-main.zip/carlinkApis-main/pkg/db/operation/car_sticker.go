package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
	"gorm.io/gorm/clause"
)

const (
	CarStickerTab          = "car_sticker"
	CarStickerStatusActive = 0
)

func GetCarStickerList(condition *model.CarSticker) (carSticker []*model.CarSticker, err error) {
	db := db.CarLinkDB.Table(CarStickerTab)

	if condition.CarStickerId != 0 {
		db = db.Where("car_sticker_id = ?", condition.CarStickerId)
	}

	if condition.CarId != 0 {
		db = db.Where("car_id = ?", condition.CarId)
	}
	if condition.StickerId != 0 {
		db = db.Where("sticker_id = ?", condition.StickerId)
	}
	db = db.Where("deleted = ?", CarStickerStatusActive)
	res := db.Find(&carSticker)
	return carSticker, res.Error
}

func UpsertCarStickers(carId uint64, carStickerReqs []*model.CarSticker) {
	db := db.CarLinkDB.Table(CarStickerTab)
	//var wg sync.WaitGroup
	//for _, carStickerReq := range carStickerReqs {
	//	wg.Add(1)
	db.Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "car_id"}, {Name: "sticker_id"}},
		DoUpdates: clause.AssignmentColumns([]string{"is_active"}),
	}).Create(&carStickerReqs)
	//}
	//wg.Wait()
	return
}
