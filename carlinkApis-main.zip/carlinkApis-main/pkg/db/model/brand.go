package model

type Brand struct {
	BrandID   uint64 `gorm:"primary_key;column:brand_id;type:bigint;not null" json:"brand_id"`
	BrandName string `gorm:"column:name;type:varchar(255);not null" json:"name"`
	Logo      string `gorm:"column:logo;type:varchar(255);not null" json:"logo"`
}
