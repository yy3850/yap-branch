package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	InspectionRemark = "inspection_remark"
	InspectionPart   = "inspection_part"
	InspectionType   = "inspection_type"
	InspectionDetail = "inspection_detail"
)

func GetInspectionRemarkList(id uint64) (remarks []*model.InspectionRemark, err error) {
	db := db.CarLinkDB.Table(InspectionRemark)
	if id != 0 {
		db = db.Where("id = ?", id)
	}

	res := db.Find(&remarks)
	return remarks, res.Error
}

func GetInspectionType(typeId uint64) (types []*model.InspectionType, err error) {
	db := db.CarLinkDB.Table(InspectionType)

	if typeId != 0 {
		db = db.Where("inspection_type_id = ?", typeId)
	}

	res := db.Find(&types)
	return types, res.Error
}

func GetInspectionPart(typeId uint64, partId uint64) (types []*model.InspectionPart, err error) {
	db := db.CarLinkDB.Table(InspectionPart)

	if typeId != 0 {
		db = db.Where("inspection_type_id = ?", typeId)
	}

	if partId != 0 {
		db = db.Where("inspection_part_id = ?", partId)
	}

	res := db.Find(&types)
	return types, res.Error
}

func GetInspectionDetail(partId uint64, detailId uint64) (details []*model.InspectionDetail, err error) {
	db := db.CarLinkDB.Table(InspectionDetail)

	if partId != 0 {
		db = db.Where("inspection_part_id = ?", partId)
	}

	if detailId != 0 {
		db = db.Where("inspection_detail_id = ?", detailId)
	}

	res := db.Find(&details)
	return details, res.Error
}
