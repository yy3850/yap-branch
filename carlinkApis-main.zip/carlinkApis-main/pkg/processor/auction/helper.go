package auction

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/processor"
	"fmt"
)

func ConvertAuctionSectionResponse(auctionList []*model.Auction) (auctionResp []*params.AuctionDetail) {
	for _, auction := range auctionList {
		auctionResp = append(auctionResp, &params.AuctionDetail{
			Car:            &params.CarDetail{CarId: auction.CarId},
			AuctionSection: &params.AuctionSectionDetail{AuctionSectionId: auction.AuctionSectionId},
			AuctionId:      auction.AuctionId,
			StartingPrice:  auction.StartingPrice,
			AuctionStatus:  processor.AuctionStatusMap[auction.AuctionStatusId],
			DepositAmount:  auction.DepositAmount,
			AuctionRemark:  auction.AuctionRemark,
			Creator: &params.UserDetail{
				UserId:   auction.CreatedBy,
				UserName: auction.CreatorName},
			FinalBid: auction.FinalBid,
			Buyer: &params.UserDetail{
				UserId:   auction.BuyerId,
				UserName: auction.BuyerName},
			TotalBid:    auction.TotalBid,
			TotalBuyer:  auction.TotalBuyer,
			AuctionDate: auction.StartTimestamp,
		})
	}
	return
}

func GetDepositPrice(price float64) float64 {
	if price < 9999 {
		return 500.00
	}

	if price < 49999 {
		return 1500.00
	}

	if price < 99999 {
		return 2500.00
	}

	return 5000.00
}

func GetAuctionRemark(price float64) string {
	return fmt.Sprintf("<p>- Bidder have to deposit RM%+v first then only eligible for bidding session.</p> <p>- CARLINKMY SDN BHD does not guarantee the accuracy of the mileage shown during inspection.</p> <p>- CARLINKMY SDN BHD does not guarantee on the validity of a new car warranty.</p> <p>- The CARLINK checkup and inspection report of the car as of the date of inspection does not guarantee the quality and condition of the car onwards.</p> <p>- Car no undercarriage inspection due to limitations.&nbsp;</p> <p>- Roadtest at short distance and any faulty at high gear or high rpm cannot be identify.</p> <p>- The deposit for successful bidder is not refundable as stated in terms and conditions.&nbsp;</p> <p>- Extended warranty can be purchased by contacting our team</p> <p>- The vehicle will be sold on an &ldquo;as-is&rdquo; basis.</p>", price)
}
