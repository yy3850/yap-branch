package operation

import (
	"carlink/pkg/db"
	"carlink/pkg/db/model"
)

const (
	ColorTab           = "color"
	ColorStatusDeleted = 1
)

func GetColorList(colorId uint64) (colors []*model.Color, err error) {
	db := db.CarLinkDB.Table(ColorTab)

	if colorId != 0 {
		db = db.Where("color_id = ?", colorId)
	}

	db = db.Where("deleted != ?", ColorStatusDeleted)
	res := db.Find(&colors)
	return colors, res.Error
}
