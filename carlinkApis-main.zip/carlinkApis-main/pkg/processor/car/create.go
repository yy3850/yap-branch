package car

import (
	"carlink/internal/params"
	"carlink/pkg/db/model"
	"carlink/pkg/db/operation"
	"carlink/pkg/logger"
	"carlink/pkg/processor"
	"carlink/pkg/processor/admin"
	"errors"
	"fmt"
	"regexp"
	"time"

	"github.com/gin-gonic/gin"
)

func CreateCar(c *gin.Context) {
	var req params.CreateCarPayload
	var res params.CarResponse
	res.IsSuccess = false
	if err := c.ShouldBindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	creator, err := admin.GetAdminDetail(c)
	if err != nil || creator.AdminId == 0 {
		processor.ErrorResponse(c, req, 404, "authentication failed")
		return
	}

	if err = validateCreateRequest(req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	newCar, err := operation.InsertCar(&model.Car{
		UserId:           req.UserId,
		LicensePlateNo:   req.LicensePlateNo,
		Mileage:          req.Mileage,
		ManufactureYear:  req.ManufactureYear,
		RegistrationDate: req.RegistrationDate,
		BrandId:          req.BrandId,
		ModelId:          req.ModelId,
		VariantId:        req.VariantId,
		TransmissionId:   req.TransmissionId,
		EngineNo:         req.EngineNo,
		EngineCapacity:   req.EngineCapacity,
		ChassisNo:        req.ChassisNo,
		ColorId:          req.ColorId,
		FuelType:         req.FuelType,
		ExistingLoan:     req.ExistingLoan,
		NoOfSeat:         req.NoOfSeat,
		StateId:          req.StateId,
		RegistrationType: req.RegistrationType,
		SellWithPlateNo:  req.SellWithPlateNo,
		AuctionRemark:    req.AuctionRemark,
		Price:            req.Price,
		CreatedBy:        creator.AdminId,
		ModifyBy:         creator.AdminId,
		CreateTime:       time.Now().Unix(),
		UpdateTime:       time.Now().Unix(),
		Status:           operation.CarStatusPending,
	})

	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	carDetail, _ := operation.GetCarWithObjectById(newCar.CarId)

	res.CarDetail = ConvertCarResponse(carDetail)
	res.IsSuccess = true

	logger.InfoLogger.Println(fmt.Sprintf("New car created. %+v", req))
	c.JSON(200, res)
}

func validateCreateRequest(req params.CreateCarPayload) (err error) {
	if lst, _ := operation.GetUserList(req.UserId); len(lst) == 0 {
		return errors.New("invalid user id")
	}

	if lst, _ := operation.GetModelList(req.ModelId, 0); len(lst) == 0 {
		return errors.New("invalid model id")
	}

	if lst, _ := operation.GetBrandList(req.BrandId); len(lst) == 0 {
		return errors.New("invalid brand id")
	}

	if lst, _ := operation.GetVariantList(req.VariantId, 0); len(lst) == 0 {
		return errors.New("invalid variant id")
	}

	if lst, _ := operation.GetTransmissionList(req.TransmissionId); len(lst) == 0 {
		return errors.New("invalid transmission id")
	}

	if lst, _ := operation.GetColorList(req.ColorId); len(lst) == 0 {
		return errors.New("invalid color id")
	}

	if lst, _ := operation.GetStateList(req.StateId); len(lst) == 0 {
		return errors.New("invalid state id")
	}

	aiReg, _ := regexp.Compile("^[a-zA-Z0-9]*$")
	if !aiReg.MatchString(req.LicensePlateNo) {
		return errors.New("invalid plate no")
	}
	if !aiReg.MatchString(req.EngineNo) {
		return errors.New("invalid engine no")
	}
	if !aiReg.MatchString(req.ChassisNo) {
		return errors.New("invalid chassis no")
	}

	return
}
