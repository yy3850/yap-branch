package params

type GetVariantParam struct {
	VariantId uint64 `form:"variant_id"json:"variant_id"`
	ModelId   uint64 `form:"model_id"json:"model_id" binding:"required"`
}

type GetVariantResponse struct {
	IsSuccess bool             `json:"is_success"`
	ErrorMsg  string           `json:"err_msg,omitempty"`
	Variants  []*VariantDetail `json:"variants,omitempty"`
}

type VariantDetail struct {
	VariantId   uint64 `json:"variant_id"`
	VariantName string `json:"variant_name"`
}
