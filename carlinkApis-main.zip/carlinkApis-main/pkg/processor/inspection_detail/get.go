package inspection_detail

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/processor"
	"strings"

	"github.com/gin-gonic/gin"
)

func GetInspectionDetailList(c *gin.Context) {
	var req params.GetInspectionDetailPayload
	var res params.GetInspectionDetailResponse
	res.IsSuccess = false

	if err := c.ShouldBindQuery(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	// err := admin.IsValidToken(c)
	// if err != nil {
	// 	processor.ErrorResponse(c, req, 403, err.Error())
	// 	return
	// }

	typesResp, err := operation.GetInspectionType(req.TypeId)
	var types []*params.InspectionType
	for _, typeResp := range typesResp {
		var parts []*params.InspectionPart
		partsResp, _ := operation.GetInspectionPart(typeResp.InspectionTypeId, req.PartId)
		for _, partResp := range partsResp {
			var details []*params.InspectionDetail
			detailsResp, _ := operation.GetInspectionDetail(partResp.InspectionPartId, req.DetailId)
			for _, detailResp := range detailsResp {
				details = append(details, &params.InspectionDetail{
					InspectionDetailId: detailResp.InspectionDetailId,
					Name:               detailResp.Name,
				})
			}

			var remarks []*params.RemarkDetail
			for _, r := range strings.Split(partResp.AvailableRemarkId, ",") {
				remarks = append(remarks, &params.RemarkDetail{
					RemarkId: r,
					Name:     processor.InspectionRemarkMap[r],
				})
			}

			if details != nil {
				parts = append(parts, &params.InspectionPart{
					InspectionPartId: partResp.InspectionPartId,
					Name:             partResp.Name,
					AvailableRemark:  remarks,
					InspectionDetail: details,
				})
			}
		}

		if parts != nil {
			types = append(types, &params.InspectionType{
				InspectionTypeId: typeResp.InspectionTypeId,
				Name:             typeResp.Name,
				InspectionParts:  parts,
			})
		}
	}

	if err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}

	res.InspectionType = types
	res.IsSuccess = true
	c.JSON(200, res)
}
