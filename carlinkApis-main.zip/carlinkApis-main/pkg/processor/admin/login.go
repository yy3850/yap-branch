package admin

import (
	"carlink/internal/params"
	"carlink/pkg/db/operation"
	"carlink/pkg/logger"
	"carlink/pkg/processor"
	"crypto/sha512"
	"fmt"
	"github.com/gin-gonic/gin"
)

func Login(c *gin.Context) {
	var req params.AdminLoginPayload
	var res params.AdminLoginResponse
	res.IsSuccess = false
	if err := c.ShouldBindJSON(&req); err != nil {
		processor.ErrorResponse(c, req, 400, err.Error())
		return
	}
	admin, err := operation.GetAdminByUserName(req.UserName)
	if err != nil {
		logger.ErrorLogger.Println(fmt.Sprintf("log in failed for user %+v", req.UserName))
		processor.ErrorResponse(c, req, 403, err.Error())
		return
	}

	// password verification
	hashedPassword := fmt.Sprintf("%x", sha512.Sum512([]byte(fmt.Sprintf("%+v%+v", admin.Salt, req.Password))))
	if hashedPassword != admin.Password {
		logger.ErrorLogger.Println(fmt.Sprintf("Admin %+v log in failed", admin.AdminId))
		processor.ErrorResponse(c, req, 403, "Invalid password")
		return
	}

	// generate token if not exist
	if admin.Token == "" {
		admin.Token = GenerateToken(admin.Email)
		operation.UpdateAdmin(admin.AdminId, &admin)
	}

	res.Admin = &params.AdminDetail{
		AdminId:   admin.AdminId,
		RoleId:    admin.RoleId,
		CompanyId: admin.CompanyId,
		UserName:  admin.UserName,
		Name:      admin.Name,
		Token:     admin.Token,
	}
	res.IsSuccess = true

	logger.InfoLogger.Println(fmt.Sprintf("Admin %+v log in", admin.AdminId))
	c.JSON(200, res)
}
