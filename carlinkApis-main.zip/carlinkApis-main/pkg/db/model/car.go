package model

type Car struct {
	CarId            uint64  `gorm:"primary_key;column:car_id;type:bigint;not null" json:"car_id"`
	UserId           uint64  `gorm:"column:users_id;type:int;not null" json:"users_id"`
	LicensePlateNo   string  `gorm:"column:lisence_plate_no;type:varchar(255);not null" json:"lisence_plate_no"`
	Mileage          uint64  `gorm:"column:mileage_v2;type:varchar(255);not null" json:"mileage_v2"`
	ManufactureYear  uint64  `gorm:"column:manufacture_year;type:int;not null" json:"manufacture_year"`
	RegistrationDate uint32  `gorm:"column:registration_date_v2;type:int;not null" json:"registration_date_v2"`
	BrandId          uint64  `gorm:"column:brand_id_copy;type:int;not null" json:"brand_id_copy"`
	ModelId          uint64  `gorm:"column:model_id;type:int;not null" json:"model_id"`
	VariantId        uint64  `gorm:"column:variant_id;type:int;not null" json:"variant_id"`
	TransmissionId   uint64  `gorm:"column:transmission_id;type:int;not null" json:"transmission_id"`
	EngineNo         string  `gorm:"column:engine_no;type:varchar(255);not null" json:"engine_no"`
	EngineCapacity   string  `gorm:"column:engine_capacity;type:int;not null" json:"engine_capacity"`
	ChassisNo        string  `gorm:"column:chassis_no;type:varchar(255);not null" json:"chassis_no"`
	ColorId          uint64  `gorm:"column:color_id;type:int;not null" json:"color_id"`
	FuelType         string  `gorm:"column:fuel_type;type:varchar(255);not null" json:"fuel_type"`
	ExistingLoan     bool    `gorm:"column:existing_loan_v2;type:boolean;not null" json:"existing_loan_v2"`
	NoOfSeat         uint64  `gorm:"column:no_of_seat;type:int;not null" json:"no_of_seat"`
	StateId          uint64  `gorm:"column:state_id;type:int;not null" json:"state_id"`
	RegistrationType string  `gorm:"column:registration_type;type:int;not null" json:"registration_type"`
	SellWithPlateNo  bool    `gorm:"column:sell_with_plate_no;type:boolean;not null" json:"sell_with_plate_no"`
	AuctionRemark    string  `gorm:"column:remark;type:varchar(255);not null" json:"auction_remark"`
	Price            float64 `gorm:"column:price;type:float;not null" json:"price"`
	CreatedBy        uint64  `gorm:"column:created_by;type:varchar(255);not null" json:"created_by"`
	ModifyBy         uint64  `gorm:"column:modified_by;type:varchar(255);not null" json:"modified_by"`
	CreateTime       int64   `gorm:"column:create_time;type:int;not null" json:"create_time"`
	UpdateTime       int64   `gorm:"column:update_time;type:int;not null" json:"update_time"`
	Status           string  `gorm:"column:status;type:varchar(255);not null" json:"status"`
}

type CarWithObject struct {
	CarId            uint64  `gorm:"primary_key;column:car_id;type:bigint;not null" json:"car_id"`
	UserId           uint64  `gorm:"column:users_id;type:int;not null" json:"users_id"`
	LicensePlateNo   string  `gorm:"column:lisence_plate_no;type:varchar(255);not null" json:"lisence_plate_no"`
	Mileage          uint64  `gorm:"column:mileage_v2;type:varchar(255);not null" json:"mileage_v2"`
	ManufactureYear  uint64  `gorm:"column:manufacture_year;type:int;not null" json:"manufacture_year"`
	RegistrationDate uint32  `gorm:"column:registration_date_v2;type:int;not null" json:"registration_date_v2"`
	BrandId          uint64  `gorm:"column:brand_id_copy;type:int;not null" json:"brand_id_copy"`
	BrandName        string  `gorm:"column:brand_name;type:int;not null" json:"brand_name"`
	ModelId          uint64  `gorm:"column:model_id;type:int;not null" json:"model_id"`
	ModelName        string  `gorm:"column:model_name;type:int;not null" json:"model_name"`
	VariantId        uint64  `gorm:"column:variant_id;type:int;not null" json:"variant_id"`
	VariantName      string  `gorm:"column:variant_name;type:int;not null" json:"variant_name"`
	TransmissionId   uint64  `gorm:"column:transmission_id;type:int;not null" json:"transmission_id"`
	TransmissionName string  `gorm:"column:transmission_name;type:int;not null" json:"transmission_name"`
	EngineNo         string  `gorm:"column:engine_no;type:varchar(255);not null" json:"engine_no"`
	EngineCapacity   string  `gorm:"column:engine_capacity;type:int;not null" json:"engine_capacity"`
	ChassisNo        string  `gorm:"column:chassis_no;type:varchar(255);not null" json:"chassis_no"`
	ColorId          uint64  `gorm:"column:color_id;type:int;not null" json:"color_id"`
	ColorName        string  `gorm:"column:color_name;type:varchar(255);not null" json:"color_name"`
	FuelType         string  `gorm:"column:fuel_type;type:varchar(255);not null" json:"fuel_type"`
	ExistingLoan     bool    `gorm:"column:existing_loan_v2;type:boolean;not null" json:"existing_loan_v2"`
	NoOfSeat         uint64  `gorm:"column:no_of_seat;type:int;not null" json:"no_of_seat"`
	StateId          uint64  `gorm:"column:state_id;type:int;not null" json:"state_id"`
	StateName        string  `gorm:"column:state_name;type:int;not null" json:"state_name"`
	RegistrationType string  `gorm:"column:registration_type;type:int;not null" json:"registration_type"`
	SellWithPlateNo  bool    `gorm:"column:sell_with_plate_no;type:boolean;not null" json:"sell_with_plate_no"`
	AuctionRemark    string  `gorm:"column:remark;type:varchar(255);not null" json:"auction_remark"`
	Price            float64 `gorm:"column:price;type:float;not null" json:"price"`
	CreatedBy        uint64  `gorm:"column:created_by;type:varchar(255);not null" json:"created_by"`
	ModifyBy         uint64  `gorm:"column:modified_by;type:varchar(255);not null" json:"modified_by"`
	CreateTime       int64   `gorm:"column:create_time;type:int;not null" json:"create_time"`
	UpdateTime       int64   `gorm:"column:update_time;type:int;not null" json:"update_time"`
	DisplayUrl       string  `gorm:"column:display_url;type:varchar(255);not null" json:"display_url"`
	Status           string  `gorm:"column:status;type:varchar(255);not null" json:"status"`
}
