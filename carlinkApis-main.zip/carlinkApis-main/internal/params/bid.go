package params

type GetBidRequest struct {
	AuctionId uint64 `form:"auction_id"json:"auction_id" binding:"required"`
}

type GetBidResponse struct {
	IsSuccess bool         `json:"is_success"`
	ErrorMsg  string       `json:"err_msg,omitempty"`
	BidList   []*BidDetail `json:"bid_list,omitempty"`
}

type BidDetail struct {
	Price      float32     `json:"price"`
	UserDetail *UserDetail `json:"user_detail"`
}
