package model

type User struct {
	UserId   uint64 `gorm:"primary_key;column:users_id;type:bigint;not null" json:"users_id"`
	UserName string `gorm:"column:username;type:bigint;not null" json:"username"`
	Name     string `gorm:"column:name;type:varchar(255);not null" json:"name"`
	Email    string `gorm:"column:email;type:bigint;not null" json:"email"`
	Contact  uint64 `gorm:"column:contact;type:varchar(255);not null" json:"contact"`
	Image    string `gorm:"column:thumbnail;type:bigint;not null" json:"thumbnail"`
}
